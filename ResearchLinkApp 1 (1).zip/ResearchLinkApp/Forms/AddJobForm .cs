﻿using ResearchLinkApp.Models;
using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class AddJobForm : Form
    {
        private int authorId;
        private DatabaseHelper dbHelper;
        public AddJobForm(int authorId)
        {
            InitializeComponent();
            this.authorId = authorId;
            dbHelper = new DatabaseHelper();
        }

        private void AddJobForm_Load(object sender, EventArgs e)
        {

        }

        private void txtJobTitle_TextChanged(object sender, EventArgs e)
        {
            


        }

        private void txtDiscription_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string jobTitle = txtJobTitle.Text.Trim();
            string description = txtDescription.Text.Trim();

            if (string.IsNullOrEmpty(jobTitle))
            {
                MessageBox.Show("Job title is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            JobPosting jobPosting = new JobPosting
            {
                PostedByAuthorID = authorId,
                JobTitle = jobTitle,
                Description = description,
                PostedDate = DateTime.Now
            };

            try
            {
                dbHelper.CreateJobPosting(jobPosting);
                MessageBox.Show("Job added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding job: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
