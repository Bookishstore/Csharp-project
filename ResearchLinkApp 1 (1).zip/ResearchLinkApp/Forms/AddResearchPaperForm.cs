﻿using ResearchLinkApp.Models;
using ResearchLinkApp.Utilities;
using System;
using System.Data;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class AddResearchPaperForm : Form
    {
        private int currentAuthorId; // Holds the ID of the current author
        private DatabaseHelper dbHelper; // Utility for database operations

        public AddResearchPaperForm(int authorId)
        {
            InitializeComponent();
            currentAuthorId = authorId;
            dbHelper = new DatabaseHelper();

            // Load available domains into the combo box
            this.Load += AddResearchPaperForm_Load;
            btnAddDomain.Click += btnAddDomain_Click;
            btnSave.Click += btnSave_Click;
            btnCancel.Click += btnCancel_Click;

            //prevent multiple subscriptions to events
            btnAddDomain.Click -= btnAddDomain_Click;
            btnSave.Click -= btnSave_Click;
            btnCancel.Click -= btnCancel_Click;
        }

        private void LoadDomains()
        {
            try
            {
                DataTable domains = dbHelper.GetAllDomains();
                cmbDomain.DataSource = domains;
                cmbDomain.DisplayMember = "DomainName";
                cmbDomain.ValueMember = "DomainID";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading domains: " + ex.Message);
            }
        }

        private void AddResearchPaperForm_Load(object sender, EventArgs e)
        {
            LoadDomains();
        }

        private void btnAddDomain_Click(object sender, EventArgs e)
        {
            string newDomainName = txtNewDomain.Text.Trim();

            if (string.IsNullOrEmpty(newDomainName))
            {
                MessageBox.Show("Domain name cannot be empty.");
                return;
            }

            try
            {
                int newDomainId = dbHelper.AddDomain(newDomainName);
                MessageBox.Show("Domain added successfully.");
                LoadDomains(); // Refresh domain list

                // Set the newly added domain as the selected item
                cmbDomain.SelectedValue = newDomainId;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding domain: " + ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Add the research paper to the database
                ResearchPaper newPaper = new ResearchPaper
                {
                    Title = txtTitle.Text,
                    JournalLink = txtJournalLink.Text,
                    ThumbnailLink = txtThumbnailLink.Text,
                    DomainID = (int)cmbDomain.SelectedValue,
                    AuthorID = currentAuthorId,
                    Status = "Pending",
                    CreatedDate = DateTime.Now
                };
                dbHelper.CreateResearchPaper(newPaper);

                MessageBox.Show("Research paper added successfully!");

                // Refresh the parent form's DataGridView
                if (this.Owner is ResearchPapersControl parentForm)
                {
                    parentForm.LoadAllResearchPapers(); // Refresh data
                }

                this.DialogResult = DialogResult.OK; // Close the form
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving research paper: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; // Indicate cancellation
            this.Close();
        }
    }
}
