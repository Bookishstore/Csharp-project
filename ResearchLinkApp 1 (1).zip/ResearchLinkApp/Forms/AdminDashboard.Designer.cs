﻿namespace ResearchLinkApp.Forms
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.navPanel = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dasboardLabel = new System.Windows.Forms.Label();
            this.deshboardPanel = new System.Windows.Forms.Panel();
            this.btnJobs = new System.Windows.Forms.Button();
            this.btnPapers = new System.Windows.Forms.Button();
            this.btnUser = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.navPanel.SuspendLayout();
            this.deshboardPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // navPanel
            // 
            this.navPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.navPanel.Controls.Add(this.btnLogout);
            this.navPanel.Controls.Add(this.label1);
            this.navPanel.Controls.Add(this.dasboardLabel);
            this.navPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.navPanel.Location = new System.Drawing.Point(0, 0);
            this.navPanel.Name = "navPanel";
            this.navPanel.Size = new System.Drawing.Size(1302, 100);
            this.navPanel.TabIndex = 0;
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = global::ResearchLinkApp.Properties.Resources.sign_out;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Location = new System.Drawing.Point(1191, 30);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(65, 49);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 16.125F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(560, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 52);
            this.label1.TabIndex = 1;
            this.label1.Text = "ResearchLink";
            // 
            // dasboardLabel
            // 
            this.dasboardLabel.AutoSize = true;
            this.dasboardLabel.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dasboardLabel.Location = new System.Drawing.Point(24, 30);
            this.dasboardLabel.Name = "dasboardLabel";
            this.dasboardLabel.Size = new System.Drawing.Size(258, 45);
            this.dasboardLabel.TabIndex = 0;
            this.dasboardLabel.Text = "Admin Panel";
            // 
            // deshboardPanel
            // 
            this.deshboardPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.deshboardPanel.Controls.Add(this.btnJobs);
            this.deshboardPanel.Controls.Add(this.btnPapers);
            this.deshboardPanel.Controls.Add(this.btnUser);
            this.deshboardPanel.Controls.Add(this.btnDashboard);
            this.deshboardPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.deshboardPanel.Location = new System.Drawing.Point(0, 100);
            this.deshboardPanel.Name = "deshboardPanel";
            this.deshboardPanel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.deshboardPanel.Size = new System.Drawing.Size(317, 880);
            this.deshboardPanel.TabIndex = 1;
            // 
            // btnJobs
            // 
            this.btnJobs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJobs.FlatAppearance.BorderSize = 0;
            this.btnJobs.Font = new System.Drawing.Font("Mongolian Baiti", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobs.Location = new System.Drawing.Point(3, 383);
            this.btnJobs.Name = "btnJobs";
            this.btnJobs.Size = new System.Drawing.Size(314, 93);
            this.btnJobs.TabIndex = 4;
            this.btnJobs.Text = "Jobs";
            this.btnJobs.UseVisualStyleBackColor = true;
            this.btnJobs.Click += new System.EventHandler(this.btnJobs_Click);
            // 
            // btnPapers
            // 
            this.btnPapers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPapers.FlatAppearance.BorderSize = 0;
            this.btnPapers.Font = new System.Drawing.Font("Mongolian Baiti", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPapers.Location = new System.Drawing.Point(3, 250);
            this.btnPapers.Name = "btnPapers";
            this.btnPapers.Size = new System.Drawing.Size(314, 93);
            this.btnPapers.TabIndex = 3;
            this.btnPapers.Text = "Papers";
            this.btnPapers.UseVisualStyleBackColor = true;
            this.btnPapers.Click += new System.EventHandler(this.btnPapers_Click);
            // 
            // btnUser
            // 
            this.btnUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUser.FlatAppearance.BorderSize = 0;
            this.btnUser.Font = new System.Drawing.Font("Mongolian Baiti", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUser.Location = new System.Drawing.Point(3, 121);
            this.btnUser.Name = "btnUser";
            this.btnUser.Size = new System.Drawing.Size(314, 93);
            this.btnUser.TabIndex = 1;
            this.btnUser.Text = "Users";
            this.btnUser.UseVisualStyleBackColor = true;
            this.btnUser.Click += new System.EventHandler(this.btnUser_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.Font = new System.Drawing.Font("Mongolian Baiti", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(3, 0);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(314, 93);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // contentPanel
            // 
            this.contentPanel.AutoSize = true;
            this.contentPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentPanel.Location = new System.Drawing.Point(317, 100);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(985, 880);
            this.contentPanel.TabIndex = 2;
            this.contentPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.contentPanel_Paint);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 980);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.deshboardPanel);
            this.Controls.Add(this.navPanel);
            this.Name = "AdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminDashboard";
            this.Load += new System.EventHandler(this.AdminDashboard_Load);
            this.navPanel.ResumeLayout(false);
            this.navPanel.PerformLayout();
            this.deshboardPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.Panel navPanel;
        private System.Windows.Forms.Panel deshboardPanel;
        private System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.Label dasboardLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnUser;
        private System.Windows.Forms.Button btnPapers;
        private System.Windows.Forms.Button btnJobs;
        private System.Windows.Forms.Button btnLogout;
    }
}