﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class AdminDashboard : Form
    {
        
        public AdminDashboard()
        {
            InitializeComponent();
            btnDashboard.Click += btnDashboard_Click;
            btnUser.Click += btnUser_Click;
            btnPapers.Click += btnPapers_Click;
            btnJobs.Click += btnJobs_Click;
        }
        private void LoadFormIntoPanel(Form form)
        {
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            contentPanel.Controls.Clear();
            contentPanel.Controls.Add(form);
            form.Show();
        }

        private void contentPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ManageHomeDashboard manageHomeDashboard = new ManageHomeDashboard();
            LoadFormIntoPanel(manageHomeDashboard);

        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            ManageUserDashboard manageUserDashboard = new ManageUserDashboard();
            LoadFormIntoPanel(manageUserDashboard);
        }

       

        private void btnPapers_Click(object sender, EventArgs e)
        {
            ManagePapersDashboard managePapersDashboard = new ManagePapersDashboard();
            LoadFormIntoPanel(managePapersDashboard);
        }

        private void btnJobs_Click(object sender, EventArgs e)
        {
            ManageJobsDashboard manageJobsDashboard = new ManageJobsDashboard();
            LoadFormIntoPanel(manageJobsDashboard);
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Optional: Confirm logout
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Hide the current dashboard
                this.Hide();

                // Show the LoginForm
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }

        }
       

    }
}
