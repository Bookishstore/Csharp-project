﻿namespace ResearchLinkApp.Forms
{
    partial class AuthorDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lnkJobPostings = new System.Windows.Forms.LinkLabel();
            this.lnkResearchPapers = new System.Windows.Forms.LinkLabel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.lnkJobPostings);
            this.panel1.Controls.Add(this.lnkResearchPapers);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1302, 100);
            this.panel1.TabIndex = 0;
            // 
            // lnkJobPostings
            // 
            this.lnkJobPostings.AutoSize = true;
            this.lnkJobPostings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkJobPostings.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkJobPostings.LinkColor = System.Drawing.Color.Black;
            this.lnkJobPostings.Location = new System.Drawing.Point(915, 39);
            this.lnkJobPostings.Name = "lnkJobPostings";
            this.lnkJobPostings.Size = new System.Drawing.Size(152, 29);
            this.lnkJobPostings.TabIndex = 4;
            this.lnkJobPostings.TabStop = true;
            this.lnkJobPostings.Text = "Create Jobs";
            this.lnkJobPostings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkJobPostings_LinkClicked);
            // 
            // lnkResearchPapers
            // 
            this.lnkResearchPapers.AutoSize = true;
            this.lnkResearchPapers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkResearchPapers.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkResearchPapers.LinkColor = System.Drawing.Color.Black;
            this.lnkResearchPapers.Location = new System.Drawing.Point(662, 39);
            this.lnkResearchPapers.Name = "lnkResearchPapers";
            this.lnkResearchPapers.Size = new System.Drawing.Size(208, 29);
            this.lnkResearchPapers.TabIndex = 3;
            this.lnkResearchPapers.TabStop = true;
            this.lnkResearchPapers.Text = "Research Papers";
            this.lnkResearchPapers.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkResearchPapers_LinkClicked);
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = global::ResearchLinkApp.Properties.Resources.sign_out;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Location = new System.Drawing.Point(1156, 32);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(47, 45);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 16.125F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(253, 52);
            this.label2.TabIndex = 1;
            this.label2.Text = "Research Link";
            // 
            // contentPanel
            // 
            this.contentPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentPanel.Location = new System.Drawing.Point(0, 100);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(1302, 880);
            this.contentPanel.TabIndex = 3;
            // 
            // AuthorDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 980);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Name = "AuthorDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AuthorDashboard";
            this.Load += new System.EventHandler(this.AuthorDashboard_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel lnkResearchPapers;
        private System.Windows.Forms.LinkLabel lnkJobPostings;
        private System.Windows.Forms.Panel contentPanel;
    }
}