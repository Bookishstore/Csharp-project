﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class AuthorDashboard : Form
    {
        private int currentAuthorId; // Current author's ID
        private DatabaseHelper dbHelper;
        public AuthorDashboard(int authorId) // Modified constructor to accept authorId
        {
            InitializeComponent();
            currentAuthorId = authorId; // Initialize currentAuthorId
            dbHelper = new DatabaseHelper(); // Initialize DatabaseHelper

            // Subscribe to LinkLabel Click Events
            lnkResearchPapers.LinkClicked += lnkResearchPapers_LinkClicked;
            lnkJobPostings.LinkClicked += lnkJobPostings_LinkClicked;
            //lnkProfile.LinkClicked += lnkProfile_LinkClicked;

            // Load the Profile Panel by default
            ResearchPapersControl panelResearchPapers = new ResearchPapersControl(currentAuthorId);
            LoadFormIntoPanel(panelResearchPapers);
        }

        private void AuthorDashboard_Load(object sender, EventArgs e)
        {
            

        }
        private void LoadFormIntoPanel(Form form)
        {
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            contentPanel.Controls.Clear();
            contentPanel.Controls.Add(form);
            form.Show();
        }

        private void lnkResearchPapers_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ResearchPapersControl panelResearchPapers = new ResearchPapersControl(currentAuthorId);
            LoadFormIntoPanel(panelResearchPapers);

        }

        private void lnkJobPostings_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            JobPostingControl panelJobPostings = new JobPostingControl(currentAuthorId);
            LoadFormIntoPanel(panelJobPostings);

        }

        private void lnkProfile_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           // PanelMyProfile panelMyProfile = new PanelMyProfile(currentAuthorId);
            //LoadFormIntoPanel(panelMyProfile);

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Optional: Confirm logout
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Hide the current dashboard
                this.Hide();

                // Show the LoginForm
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }



        }

        

    }
}
