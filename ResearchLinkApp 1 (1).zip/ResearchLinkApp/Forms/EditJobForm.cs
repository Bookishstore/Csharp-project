﻿using ResearchLinkApp.Models;
using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class EditJobForm : Form
    {
        private int jobId;
        private DatabaseHelper dbHelper;
        public EditJobForm(int jobId)
        {
            InitializeComponent();
            this.jobId = jobId;
            dbHelper = new DatabaseHelper();

            this.Load += EditJobForm_Load;
            btnSave.Click += btnSave_Click;
            btnCancel.Click += btnCancel_Click;
        }

        private void EditJobForm_Load(object sender, EventArgs e)
        {
            LoadJobDetails();

        }

        private void LoadJobDetails()
        {
            try
            {
                string query = "SELECT JobTitle, Description FROM tblJobPosting WHERE JobID = @JobID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@JobID", jobId)
                };

                DataTable jobData = dbHelper.ExecuteReader(query, parameters);

                if (jobData.Rows.Count > 0)
                {
                    DataRow row = jobData.Rows[0];
                    txtJobTitle.Text = row["JobTitle"].ToString();
                    txtDescription.Text = row["Description"] == DBNull.Value ? string.Empty : row["Description"].ToString();
                }
                else
                {
                    MessageBox.Show("Job not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading job details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string jobTitle = txtJobTitle.Text.Trim();
            string description = txtDescription.Text.Trim();

            // Validate inputs
            if (string.IsNullOrEmpty(jobTitle))
            {
                MessageBox.Show("Job title is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            JobPosting jobPosting = new JobPosting
            {
                JobID = jobId,
                JobTitle = jobTitle,
                Description = description,
                UpdatedDate = DateTime.Now
            };

            try
            {
                dbHelper.UpdateJobPosting(jobPosting);
                MessageBox.Show("Job updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK; // Indicate success
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating job: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
