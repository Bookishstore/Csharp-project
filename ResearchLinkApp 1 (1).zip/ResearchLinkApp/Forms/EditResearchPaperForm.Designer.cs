﻿namespace ResearchLinkApp.Forms
{
    partial class EditResearchPaperForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbDomain = new System.Windows.Forms.Panel();
            this.combDomain = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAddDomain = new System.Windows.Forms.Button();
            this.txtNewDomain = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtThumbnailLink = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtJournalLink = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.cmbDomain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1020, 100);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(266, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(494, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Edit Your Research Paper";
            // 
            // cmbDomain
            // 
            this.cmbDomain.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.cmbDomain.Controls.Add(this.combDomain);
            this.cmbDomain.Controls.Add(this.btnCancel);
            this.cmbDomain.Controls.Add(this.btnSave);
            this.cmbDomain.Controls.Add(this.btnAddDomain);
            this.cmbDomain.Controls.Add(this.txtNewDomain);
            this.cmbDomain.Controls.Add(this.label6);
            this.cmbDomain.Controls.Add(this.label5);
            this.cmbDomain.Controls.Add(this.txtThumbnailLink);
            this.cmbDomain.Controls.Add(this.label4);
            this.cmbDomain.Controls.Add(this.txtJournalLink);
            this.cmbDomain.Controls.Add(this.label3);
            this.cmbDomain.Controls.Add(this.txtTitle);
            this.cmbDomain.Controls.Add(this.label2);
            this.cmbDomain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbDomain.Location = new System.Drawing.Point(0, 100);
            this.cmbDomain.Name = "cmbDomain";
            this.cmbDomain.Size = new System.Drawing.Size(1020, 609);
            this.cmbDomain.TabIndex = 1;
            // 
            // combDomain
            // 
            this.combDomain.FormattingEnabled = true;
            this.combDomain.Location = new System.Drawing.Point(598, 200);
            this.combDomain.Name = "combDomain";
            this.combDomain.Size = new System.Drawing.Size(285, 33);
            this.combDomain.TabIndex = 13;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(739, 422);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(144, 52);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(109, 422);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(144, 52);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAddDomain
            // 
            this.btnAddDomain.Font = new System.Drawing.Font("Mongolian Baiti", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDomain.Location = new System.Drawing.Point(394, 275);
            this.btnAddDomain.Name = "btnAddDomain";
            this.btnAddDomain.Size = new System.Drawing.Size(68, 38);
            this.btnAddDomain.TabIndex = 10;
            this.btnAddDomain.Text = "Add";
            this.btnAddDomain.UseVisualStyleBackColor = true;
            this.btnAddDomain.Click += new System.EventHandler(this.btnAddDomain_Click);
            // 
            // txtNewDomain
            // 
            this.txtNewDomain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNewDomain.Location = new System.Drawing.Point(109, 279);
            this.txtNewDomain.Name = "txtNewDomain";
            this.txtNewDomain.Size = new System.Drawing.Size(290, 31);
            this.txtNewDomain.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(104, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(229, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "Add New Domain";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(588, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(273, 29);
            this.label5.TabIndex = 6;
            this.label5.Text = "Choose Your Domain";
            // 
            // txtThumbnailLink
            // 
            this.txtThumbnailLink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtThumbnailLink.Location = new System.Drawing.Point(109, 187);
            this.txtThumbnailLink.Name = "txtThumbnailLink";
            this.txtThumbnailLink.Size = new System.Drawing.Size(290, 31);
            this.txtThumbnailLink.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(104, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 29);
            this.label4.TabIndex = 4;
            this.label4.Text = "Thumbnail Link";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtJournalLink
            // 
            this.txtJournalLink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtJournalLink.Location = new System.Drawing.Point(593, 88);
            this.txtJournalLink.Name = "txtJournalLink";
            this.txtJournalLink.Size = new System.Drawing.Size(290, 31);
            this.txtJournalLink.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(593, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Journal Link";
            // 
            // txtTitle
            // 
            this.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTitle.Location = new System.Drawing.Point(109, 88);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(290, 31);
            this.txtTitle.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(104, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Title";
            // 
            // EditResearchPaperForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 709);
            this.Controls.Add(this.cmbDomain);
            this.Controls.Add(this.panel1);
            this.Name = "EditResearchPaperForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditResearchPaperForm";
            this.Load += new System.EventHandler(this.EditResearchPaperForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.cmbDomain.ResumeLayout(false);
            this.cmbDomain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel cmbDomain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtJournalLink;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtThumbnailLink;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNewDomain;
        private System.Windows.Forms.Button btnAddDomain;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox combDomain;
    }
}