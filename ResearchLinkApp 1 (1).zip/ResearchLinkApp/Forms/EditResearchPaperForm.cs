﻿using ResearchLinkApp.Models;
using ResearchLinkApp.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class EditResearchPaperForm : Form
    {
        private int paperId;
        private DatabaseHelper dbHelper;

        public EditResearchPaperForm(int paperId)
        {
            InitializeComponent();
            this.paperId = paperId;
            dbHelper = new DatabaseHelper();

            this.Load += EditResearchPaperForm_Load;
            btnSave.Click += btnSave_Click;
            btnCancel.Click += btnCancel_Click;
            btnAddDomain.Click += btnAddDomain_Click;

            //pevent multiple subscriptions to events
            btnSave.Click -= btnSave_Click;
            btnCancel.Click -= btnCancel_Click;
            btnAddDomain.Click -= btnAddDomain_Click;

        }

        private void LoadDomains()
        {
            try
            {
                DataTable domains = dbHelper.GetAllDomains();
                combDomain.DataSource = domains;
                combDomain.DisplayMember = "DomainName";
                combDomain.ValueMember = "DomainID";
                combDomain.SelectedIndex = -1; // No selection by default
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading domains: " + ex.Message);
            }
        }

        private void LoadResearchPaperDetails()
        {
            try
            {
                ResearchPaper paper = dbHelper.GetResearchPaperById(paperId);
                if (paper != null)
                {
                    txtTitle.Text = paper.Title;
                    txtJournalLink.Text = paper.JournalLink ?? "";
                    txtThumbnailLink.Text = paper.ThumbnailLink ?? "";
                    combDomain.SelectedValue = paper.DomainID;
                }
                else
                {
                    MessageBox.Show("Research paper not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading research paper details: " + ex.Message);
            }
        }

        private void EditResearchPaperForm_Load(object sender, EventArgs e)
        {
            LoadDomains();
            LoadResearchPaperDetails();
        }

        private void btnAddDomain_Click(object sender, EventArgs e)
        {
            string newDomain = txtNewDomain.Text.Trim();

            if (string.IsNullOrEmpty(newDomain))
            {
                MessageBox.Show("Please enter a domain name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int newDomainId = dbHelper.AddDomain(newDomain);
                MessageBox.Show("New domain added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDomains(); // Refresh domains
                combDomain.SelectedValue = newDomainId; // Set newly added domain
                txtNewDomain.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding domain: " + ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text.Trim();
            string journalLink = txtJournalLink.Text.Trim();
            string thumbnailLink = txtThumbnailLink.Text.Trim();
            object selectedDomain = combDomain.SelectedValue;

            // Input Validation
            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Title is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (selectedDomain == null)
            {
                MessageBox.Show("Please select a domain.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int domainId = Convert.ToInt32(selectedDomain);

            ResearchPaper updatedPaper = new ResearchPaper
            {
                PaperID = paperId,
                Title = title,
                JournalLink = string.IsNullOrEmpty(journalLink) ? null : journalLink,
                ThumbnailLink = string.IsNullOrEmpty(thumbnailLink) ? null : thumbnailLink,
                DomainID = domainId
            };

            try
            {
                dbHelper.UpdateResearchPaper(updatedPaper);
                MessageBox.Show("Research paper updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating research paper: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            // Placeholder for label4 click event
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
