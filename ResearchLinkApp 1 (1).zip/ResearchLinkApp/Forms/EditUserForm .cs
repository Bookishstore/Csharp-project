﻿using System;
using System.Data;
using System.Windows.Forms;
using ResearchLinkApp.Utilities;

namespace ResearchLinkApp.Forms
{
    public partial class EditUserForm : Form
    {
        private int userId;
        private DatabaseHelper dbHelper;

        public EditUserForm(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            dbHelper = new DatabaseHelper();

            btnSave.Click += btnSave_Click;
            btnCancel.Click -= btnCancel_Click;
        }

        private void EditUserForm_Load(object sender, EventArgs e)
        {
            LoadUserDetails();
        }

        private void LoadUserDetails()
        {
            try
            {
                //User details from database helper
                DataRow userDetails = dbHelper.GetUserById(userId);

                if (userDetails != null)
                {
                    // Populate fields
                    txtUsername.Text = userDetails["Username"].ToString();
                    txtEmail.Text = userDetails["Email"].ToString();
                   
                }
                else
                {
                    MessageBox.Show("User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading user details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate input
                if (string.IsNullOrEmpty(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("Email cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Update email in the database
                dbHelper.UpdateUserEmail(userId, txtEmail.Text.Trim());

                MessageBox.Show("User details updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Close the form
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving user details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
