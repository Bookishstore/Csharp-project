﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class JobApplication : Form
    {
        private int currentUserId;
        private int jobId;
        private string jobTitle;
        public JobApplication(int  currentUserId, int jobId, string jobTitle)
        {
            InitializeComponent();
            this.currentUserId = currentUserId;
            this.jobId = jobId;
            this.jobTitle = jobTitle;

            // Set Job Title in TextBox
            txtTitle.Text = jobTitle;
        }

        private void JobApplication_Load(object sender, EventArgs e)
        {
           
            

        }

        private void btnJobApply_Click(object sender, EventArgs e)
        {
            ApplyForJob();
            this.Close();
        }

        private void ApplyForJob()
        {
            try
            {
                DatabaseHelper dbHelper = new DatabaseHelper();
                string additionalMessage = txtAdditionalMessage.Text.Trim();

                // Check if skills field is empty
                if (string.IsNullOrEmpty(additionalMessage))
                {
                    MessageBox.Show("Please describe your skills before applying.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Check if the user has already applied for the job
                string checkQuery = @"
            SELECT COUNT(*) 
            FROM tblJobApplication 
            WHERE UserID = @UserID AND JobID = @JobID";

                SqlParameter[] checkParameters = new SqlParameter[]
                {
            new SqlParameter("@UserID", currentUserId),
            new SqlParameter("@JobID", jobId)
                };

                int applicationCount = Convert.ToInt32(dbHelper.ExecuteScalar(checkQuery, checkParameters));

                if (applicationCount > 0)
                {
                    MessageBox.Show("You have already applied for this job.", "Duplicate Application", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Insert application into tblJobApplication
                string insertQuery = @"
                INSERT INTO tblJobApplication 
                (UserID, JobID, AppliedDate, AdditionalMessage, Status)
                VALUES (@UserID, @JobID, @AppliedDate, @AdditionalMessage, 'Pending')";

                SqlParameter[] insertParameters = new SqlParameter[]
                {
                new SqlParameter("@UserID", currentUserId),
                new SqlParameter("@JobID", jobId),
                new SqlParameter("@AppliedDate", DateTime.Now),
                new SqlParameter("@AdditionalMessage", additionalMessage)
                };

                dbHelper.ExecuteNonQuery(insertQuery, insertParameters);

                MessageBox.Show("Job application submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error applying for job: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
