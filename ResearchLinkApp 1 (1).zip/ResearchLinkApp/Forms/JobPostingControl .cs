﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class JobPostingControl : Form
    {
        private int currentAuthorId; 
        private DatabaseHelper dbHelper;
        public JobPostingControl(int authorId)
        {
            InitializeComponent();
            currentAuthorId = authorId;
            dbHelper = new DatabaseHelper();

            this.Load += JobPostingControll_Load;
            btnAdd.Click += btnAdd_Click;
            btnEdit.Click += btnEdit_Click;
            btnRemove.Click += btnRemove_Click;
            btnShowApplicants.Click += btnShowApplicants_Click;

            //Prevent multiple subscriptions to events
            btnAdd.Click -= btnAdd_Click;
            btnEdit.Click -= btnEdit_Click;
            btnShowApplicants.Click -= btnShowApplicants_Click;




            dgvJobPostings.Dock = DockStyle.Fill;
            dgvJobPostings.BackgroundColor = Color.White;
            dgvJobPostings.BorderStyle = BorderStyle.Fixed3D;
            dgvJobPostings.RowHeadersVisible = false;
            dgvJobPostings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void JobPostingControll_Load(object sender, EventArgs e)
        {
            LoadAllJobPostings();

        }
        private void LoadAllJobPostings()
        {
            try
            {
                DataTable jobPostings = dbHelper.GetJobPostingsByAuthor(currentAuthorId);
                dgvJobPostings.DataSource = jobPostings;

                // Adjust column headers
                dgvJobPostings.Columns["JobID"].Visible = false;
                dgvJobPostings.Columns["JobTitle"].HeaderText = "Title";
                dgvJobPostings.Columns["Description"].HeaderText = "Description";
                dgvJobPostings.Columns["PostedDate"].HeaderText = "Posted Date";

                // Hide unnecessary columns
                if (dgvJobPostings.Columns.Contains("UpdatedDate"))
                {
                    dgvJobPostings.Columns["UpdatedDate"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading job postings: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddJobForm addJobForm = new AddJobForm(currentAuthorId);
            if (addJobForm.ShowDialog() == DialogResult.OK)
            {
                LoadAllJobPostings(); // Refresh after adding
            }
        }


        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvJobPostings.SelectedRows.Count == 1)
            {
                int selectedJobId = Convert.ToInt32(dgvJobPostings.SelectedRows[0].Cells["JobID"].Value);
                EditJobForm editJobForm = new EditJobForm(selectedJobId);

                if (editJobForm.ShowDialog() == DialogResult.OK)
                {
                    LoadAllJobPostings(); // Refresh after editing
                }
            }
            else
            {
                MessageBox.Show("Please select a job to edit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }



        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgvJobPostings.SelectedRows.Count == 1)
            {
                int selectedJobId = Convert.ToInt32(dgvJobPostings.SelectedRows[0].Cells["JobID"].Value);

                DialogResult confirm = MessageBox.Show("Are you sure you want to delete this job?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    try
                    {
                        dbHelper.DeleteJobPosting(selectedJobId);
                        MessageBox.Show("Job deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadAllJobPostings(); // Refresh after deletion
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting job: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a job to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnShowApplicants_Click(object sender, EventArgs e)
        {
            if (dgvJobPostings.SelectedRows.Count == 1)
            {
                int selectedJobId = Convert.ToInt32(
                    dgvJobPostings.SelectedRows[0].Cells["JobID"].Value);
                ShowApplicantsForm showApplicantsForm =
                    new ShowApplicantsForm(selectedJobId, currentAuthorId);
                showApplicantsForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a job to view applicants.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


    }

}
