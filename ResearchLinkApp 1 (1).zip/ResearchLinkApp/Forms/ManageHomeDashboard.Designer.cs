﻿namespace ResearchLinkApp.Forms
{
    partial class ManageHomeDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomePanel = new System.Windows.Forms.Panel();
            this.welcomeText = new System.Windows.Forms.Label();
            this.totalUserPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.totalAuthorPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.paperPanel = new System.Windows.Forms.Panel();
            this.totalPaperPanel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.totalJobPanel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblotalUsers = new System.Windows.Forms.Label();
            this.lblTotalAuthors = new System.Windows.Forms.Label();
            this.lblTotalResearchPapers = new System.Windows.Forms.Label();
            this.lblTotalJobs = new System.Windows.Forms.Label();
            this.welcomePanel.SuspendLayout();
            this.totalUserPanel.SuspendLayout();
            this.totalAuthorPanel.SuspendLayout();
            this.paperPanel.SuspendLayout();
            this.totalJobPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // welcomePanel
            // 
            this.welcomePanel.Controls.Add(this.welcomeText);
            this.welcomePanel.Location = new System.Drawing.Point(173, 38);
            this.welcomePanel.Name = "welcomePanel";
            this.welcomePanel.Size = new System.Drawing.Size(655, 82);
            this.welcomePanel.TabIndex = 0;
            // 
            // welcomeText
            // 
            this.welcomeText.AutoSize = true;
            this.welcomeText.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeText.Location = new System.Drawing.Point(148, 15);
            this.welcomeText.Name = "welcomeText";
            this.welcomeText.Size = new System.Drawing.Size(329, 45);
            this.welcomeText.TabIndex = 0;
            this.welcomeText.Text = "Welcome Admin";
            // 
            // totalUserPanel
            // 
            this.totalUserPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalUserPanel.Controls.Add(this.lblotalUsers);
            this.totalUserPanel.Controls.Add(this.label1);
            this.totalUserPanel.Controls.Add(this.panel1);
            this.totalUserPanel.Location = new System.Drawing.Point(47, 139);
            this.totalUserPanel.Name = "totalUserPanel";
            this.totalUserPanel.Size = new System.Drawing.Size(386, 167);
            this.totalUserPanel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(81, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "Total Users";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ResearchLinkApp.Properties.Resources.users_alt;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(14, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(48, 52);
            this.panel1.TabIndex = 0;
            // 
            // totalAuthorPanel
            // 
            this.totalAuthorPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalAuthorPanel.Controls.Add(this.lblTotalAuthors);
            this.totalAuthorPanel.Controls.Add(this.label2);
            this.totalAuthorPanel.Controls.Add(this.panel3);
            this.totalAuthorPanel.Location = new System.Drawing.Point(554, 139);
            this.totalAuthorPanel.Name = "totalAuthorPanel";
            this.totalAuthorPanel.Size = new System.Drawing.Size(376, 167);
            this.totalAuthorPanel.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 45);
            this.label2.TabIndex = 1;
            this.label2.Text = "Total Authors";
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = global::ResearchLinkApp.Properties.Resources.users_alt;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Location = new System.Drawing.Point(14, 18);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(48, 52);
            this.panel3.TabIndex = 0;
            // 
            // paperPanel
            // 
            this.paperPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.paperPanel.Controls.Add(this.lblTotalResearchPapers);
            this.paperPanel.Controls.Add(this.totalPaperPanel);
            this.paperPanel.Controls.Add(this.panel4);
            this.paperPanel.Location = new System.Drawing.Point(60, 400);
            this.paperPanel.Name = "paperPanel";
            this.paperPanel.Size = new System.Drawing.Size(373, 167);
            this.paperPanel.TabIndex = 2;
            // 
            // totalPaperPanel
            // 
            this.totalPaperPanel.AutoSize = true;
            this.totalPaperPanel.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPaperPanel.Location = new System.Drawing.Point(68, 25);
            this.totalPaperPanel.Name = "totalPaperPanel";
            this.totalPaperPanel.Size = new System.Drawing.Size(279, 29);
            this.totalPaperPanel.TabIndex = 1;
            this.totalPaperPanel.Text = "Total Research papers";
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = global::ResearchLinkApp.Properties.Resources.research_paper;
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.Location = new System.Drawing.Point(14, 18);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(48, 52);
            this.panel4.TabIndex = 0;
            // 
            // totalJobPanel
            // 
            this.totalJobPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalJobPanel.Controls.Add(this.lblTotalJobs);
            this.totalJobPanel.Controls.Add(this.label3);
            this.totalJobPanel.Controls.Add(this.panel6);
            this.totalJobPanel.Location = new System.Drawing.Point(554, 400);
            this.totalJobPanel.Name = "totalJobPanel";
            this.totalJobPanel.Size = new System.Drawing.Size(376, 167);
            this.totalJobPanel.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(81, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 45);
            this.label3.TabIndex = 1;
            this.label3.Text = "Total Jobs";
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = global::ResearchLinkApp.Properties.Resources.users_alt;
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel6.Location = new System.Drawing.Point(14, 18);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(48, 52);
            this.panel6.TabIndex = 0;
            // 
            // lblotalUsers
            // 
            this.lblotalUsers.AutoSize = true;
            this.lblotalUsers.Font = new System.Drawing.Font("Mongolian Baiti", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblotalUsers.Location = new System.Drawing.Point(89, 97);
            this.lblotalUsers.Name = "lblotalUsers";
            this.lblotalUsers.Size = new System.Drawing.Size(45, 30);
            this.lblotalUsers.TabIndex = 2;
            this.lblotalUsers.Text = "50";
            // 
            // lblTotalAuthors
            // 
            this.lblTotalAuthors.AutoSize = true;
            this.lblTotalAuthors.Font = new System.Drawing.Font("Mongolian Baiti", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAuthors.Location = new System.Drawing.Point(69, 97);
            this.lblTotalAuthors.Name = "lblTotalAuthors";
            this.lblTotalAuthors.Size = new System.Drawing.Size(45, 30);
            this.lblTotalAuthors.TabIndex = 3;
            this.lblTotalAuthors.Text = "50";
            // 
            // lblTotalResearchPapers
            // 
            this.lblTotalResearchPapers.AutoSize = true;
            this.lblTotalResearchPapers.Font = new System.Drawing.Font("Mongolian Baiti", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalResearchPapers.Location = new System.Drawing.Point(76, 99);
            this.lblTotalResearchPapers.Name = "lblTotalResearchPapers";
            this.lblTotalResearchPapers.Size = new System.Drawing.Size(45, 30);
            this.lblTotalResearchPapers.TabIndex = 4;
            this.lblTotalResearchPapers.Text = "50";
            // 
            // lblTotalJobs
            // 
            this.lblTotalJobs.AutoSize = true;
            this.lblTotalJobs.Font = new System.Drawing.Font("Mongolian Baiti", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalJobs.Location = new System.Drawing.Point(84, 99);
            this.lblTotalJobs.Name = "lblTotalJobs";
            this.lblTotalJobs.Size = new System.Drawing.Size(45, 30);
            this.lblTotalJobs.TabIndex = 5;
            this.lblTotalJobs.Text = "50";
            // 
            // ManageHomeDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 880);
            this.Controls.Add(this.totalJobPanel);
            this.Controls.Add(this.paperPanel);
            this.Controls.Add(this.totalAuthorPanel);
            this.Controls.Add(this.totalUserPanel);
            this.Controls.Add(this.welcomePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageHomeDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "manageHomeDashboard";
            this.Load += new System.EventHandler(this.ManageHomeDashboard_Load);
            this.welcomePanel.ResumeLayout(false);
            this.welcomePanel.PerformLayout();
            this.totalUserPanel.ResumeLayout(false);
            this.totalUserPanel.PerformLayout();
            this.totalAuthorPanel.ResumeLayout(false);
            this.totalAuthorPanel.PerformLayout();
            this.paperPanel.ResumeLayout(false);
            this.paperPanel.PerformLayout();
            this.totalJobPanel.ResumeLayout(false);
            this.totalJobPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel welcomePanel;
        private System.Windows.Forms.Panel totalUserPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel totalAuthorPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel paperPanel;
        private System.Windows.Forms.Label totalPaperPanel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel totalJobPanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label welcomeText;
        private System.Windows.Forms.Label lblotalUsers;
        private System.Windows.Forms.Label lblTotalAuthors;
        private System.Windows.Forms.Label lblTotalResearchPapers;
        private System.Windows.Forms.Label lblTotalJobs;
    }
}