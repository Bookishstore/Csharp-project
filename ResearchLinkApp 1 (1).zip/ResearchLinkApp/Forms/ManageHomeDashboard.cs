﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class ManageHomeDashboard : Form
    {
        private DatabaseHelper dbHelper;
        public ManageHomeDashboard()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper();
            this.Load += ManageHomeDashboard_Load;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void ManageHomeDashboard_Load(object sender, EventArgs e)
        {
            UpdateDashboardCounts();

        }

        private void UpdateDashboardCounts()
        {
            try
            {
                // Retrieve counts from the database
                int totalUsers = dbHelper.GetTotalUsers();
                int totalAuthors = dbHelper.GetTotalAuthors();
                int totalResearchPapers = dbHelper.GetTotalResearchPapers();
                int totalJobs = dbHelper.GetTotalJobs();

                // Update the labels with retrieved values
                lblotalUsers.Text = totalUsers.ToString();
                lblTotalAuthors.Text = totalAuthors.ToString();
                lblTotalResearchPapers.Text = totalResearchPapers.ToString();
                lblTotalJobs.Text = totalJobs.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading dashboard counts: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
