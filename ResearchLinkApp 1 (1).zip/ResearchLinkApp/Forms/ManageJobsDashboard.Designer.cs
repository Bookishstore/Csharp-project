﻿namespace ResearchLinkApp.Forms
{
    partial class ManageJobsDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jobheader = new System.Windows.Forms.Panel();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.txtSearchJob = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvJobPostings = new System.Windows.Forms.DataGridView();
            this.jobheader.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobPostings)).BeginInit();
            this.SuspendLayout();
            // 
            // jobheader
            // 
            this.jobheader.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.jobheader.Controls.Add(this.BtnDelete);
            this.jobheader.Controls.Add(this.txtSearchJob);
            this.jobheader.Controls.Add(this.label1);
            this.jobheader.Dock = System.Windows.Forms.DockStyle.Top;
            this.jobheader.Location = new System.Drawing.Point(0, 0);
            this.jobheader.Name = "jobheader";
            this.jobheader.Size = new System.Drawing.Size(959, 120);
            this.jobheader.TabIndex = 0;
            this.jobheader.Paint += new System.Windows.Forms.PaintEventHandler(this.jobheader_Paint);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelete.Location = new System.Drawing.Point(795, 23);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(152, 65);
            this.BtnDelete.TabIndex = 4;
            this.BtnDelete.Text = "Remove";
            this.BtnDelete.UseVisualStyleBackColor = true;
            // 
            // txtSearchJob
            // 
            this.txtSearchJob.Location = new System.Drawing.Point(132, 23);
            this.txtSearchJob.Multiline = true;
            this.txtSearchJob.Name = "txtSearchJob";
            this.txtSearchJob.Size = new System.Drawing.Size(292, 65);
            this.txtSearchJob.TabIndex = 1;
            this.txtSearchJob.TextChanged += new System.EventHandler(this.txtSearchJobs_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvJobPostings);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 120);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 689);
            this.panel1.TabIndex = 1;
            // 
            // dgvJobPostings
            // 
            this.dgvJobPostings.AllowUserToAddRows = false;
            this.dgvJobPostings.AllowUserToDeleteRows = false;
            this.dgvJobPostings.AllowUserToResizeColumns = false;
            this.dgvJobPostings.AllowUserToResizeRows = false;
            this.dgvJobPostings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvJobPostings.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvJobPostings.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvJobPostings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJobPostings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvJobPostings.Location = new System.Drawing.Point(0, 0);
            this.dgvJobPostings.Name = "dgvJobPostings";
            this.dgvJobPostings.ReadOnly = true;
            this.dgvJobPostings.RowHeadersWidth = 82;
            this.dgvJobPostings.RowTemplate.Height = 33;
            this.dgvJobPostings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvJobPostings.Size = new System.Drawing.Size(959, 689);
            this.dgvJobPostings.TabIndex = 0;
            // 
            // ManageJobsDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 809);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.jobheader);
            this.Name = "ManageJobsDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManageJobsDashboard";
            this.Load += new System.EventHandler(this.ManageJobsDashboard_Load_1);
            this.jobheader.ResumeLayout(false);
            this.jobheader.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobPostings)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel jobheader;
        private System.Windows.Forms.TextBox txtSearchJob;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvJobPostings;
    }
}