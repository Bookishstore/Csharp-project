﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class ManageJobsDashboard : Form
    {
        private DatabaseHelper dbHelper;
        public ManageJobsDashboard()
        {
            InitializeComponent();
            this.Load += ManageJobsDashboard_Load;

            dbHelper = new DatabaseHelper();

            // Event bindings
            BtnDelete.Click += BtnDelete_Click;
            txtSearchJob.TextChanged += TxtSearchJob_TextChanged;

            // Adjust the DataGridView size and styling here
            dgvJobPostings.Dock = DockStyle.Fill;
            dgvJobPostings.BackgroundColor = Color.White;
            dgvJobPostings.BorderStyle = BorderStyle.Fixed3D;
            dgvJobPostings.RowHeadersVisible = false;
            dgvJobPostings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;



        }

        private void ManageJobsDashboard_Load(object sender, EventArgs e)
        {
            LoadAllJobPostings();

        }

        private void LoadAllJobPostings()
        {
            try
            {
                DataTable jobs = dbHelper.GetAllJobPostings();
                dgvJobPostings.DataSource = jobs;

                // Adjust DataGridView columns
                dgvJobPostings.Columns["JobID"].Visible = false; // Hide ID
                dgvJobPostings.Columns["JobTitle"].HeaderText = "Job Title";
                dgvJobPostings.Columns["PostedBy"].HeaderText = "Posted By";
                dgvJobPostings.Columns["Description"].HeaderText = "Description";
                dgvJobPostings.Columns["PostedDate"].HeaderText = "Posted Date";

                dgvJobPostings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvJobPostings.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading job postings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvJobPostings.SelectedRows.Count > 0)
            {
                int jobId = Convert.ToInt32(dgvJobPostings.SelectedRows[0].Cells["JobID"].Value);

                DialogResult confirm = MessageBox.Show(
                    "Are you sure you want to delete this job posting?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm == DialogResult.Yes)
                {
                    dbHelper.DeleteJobPosting(jobId);
                    MessageBox.Show("Job posting deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAllJobPostings();
                }
            }
            else
            {
                MessageBox.Show("Please select a job posting to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void TxtSearchJob_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearchJob.Text.Trim();

            try
            {
                if (string.IsNullOrEmpty(searchText))
                {
                    LoadAllJobPostings(); // Reload all job postings if the search box is cleared
                }
                else
                {
                    DataTable searchResults = dbHelper.SearchJobPostings(searchText);
                    dgvJobPostings.DataSource = searchResults;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching job postings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void jobheader_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ManageJobsDashboard_Load_1(object sender, EventArgs e)
        {

        }

        private void txtSearchJobs_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
