﻿namespace ResearchLinkApp.Forms
{
    partial class ManagePapersDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paperHeader = new System.Windows.Forms.Panel();
            this.cmbFilterPaper = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.txtSearchPaper = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataPanelPaper = new System.Windows.Forms.Panel();
            this.dgvResearchPapers = new System.Windows.Forms.DataGridView();
            this.paperHeader.SuspendLayout();
            this.dataPanelPaper.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResearchPapers)).BeginInit();
            this.SuspendLayout();
            // 
            // paperHeader
            // 
            this.paperHeader.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.paperHeader.Controls.Add(this.cmbFilterPaper);
            this.paperHeader.Controls.Add(this.label2);
            this.paperHeader.Controls.Add(this.btnDelete);
            this.paperHeader.Controls.Add(this.btnReject);
            this.paperHeader.Controls.Add(this.btnApprove);
            this.paperHeader.Controls.Add(this.txtSearchPaper);
            this.paperHeader.Controls.Add(this.label1);
            this.paperHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.paperHeader.Location = new System.Drawing.Point(0, 0);
            this.paperHeader.Name = "paperHeader";
            this.paperHeader.Size = new System.Drawing.Size(959, 178);
            this.paperHeader.TabIndex = 0;
            // 
            // cmbFilterPaper
            // 
            this.cmbFilterPaper.FormattingEnabled = true;
            this.cmbFilterPaper.Location = new System.Drawing.Point(120, 118);
            this.cmbFilterPaper.Name = "cmbFilterPaper";
            this.cmbFilterPaper.Size = new System.Drawing.Size(292, 33);
            this.cmbFilterPaper.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Filter :";
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(784, 36);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(152, 65);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnReject
            // 
            this.btnReject.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(606, 35);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(152, 65);
            this.btnReject.TabIndex = 3;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = true;
            // 
            // btnApprove
            // 
            this.btnApprove.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApprove.Location = new System.Drawing.Point(431, 35);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(152, 65);
            this.btnApprove.TabIndex = 2;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = true;
            this.btnApprove.Click += new System.EventHandler(this.btnAddPaper_Click);
            // 
            // txtSearchPaper
            // 
            this.txtSearchPaper.Location = new System.Drawing.Point(120, 35);
            this.txtSearchPaper.Multiline = true;
            this.txtSearchPaper.Name = "txtSearchPaper";
            this.txtSearchPaper.Size = new System.Drawing.Size(292, 65);
            this.txtSearchPaper.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search:";
            // 
            // dataPanelPaper
            // 
            this.dataPanelPaper.Controls.Add(this.dgvResearchPapers);
            this.dataPanelPaper.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataPanelPaper.Location = new System.Drawing.Point(0, 178);
            this.dataPanelPaper.Name = "dataPanelPaper";
            this.dataPanelPaper.Size = new System.Drawing.Size(959, 631);
            this.dataPanelPaper.TabIndex = 1;
            // 
            // dgvResearchPapers
            // 
            this.dgvResearchPapers.AllowUserToAddRows = false;
            this.dgvResearchPapers.AllowUserToDeleteRows = false;
            this.dgvResearchPapers.AllowUserToResizeColumns = false;
            this.dgvResearchPapers.AllowUserToResizeRows = false;
            this.dgvResearchPapers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResearchPapers.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvResearchPapers.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvResearchPapers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResearchPapers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResearchPapers.Location = new System.Drawing.Point(0, 0);
            this.dgvResearchPapers.Name = "dgvResearchPapers";
            this.dgvResearchPapers.ReadOnly = true;
            this.dgvResearchPapers.RowHeadersWidth = 82;
            this.dgvResearchPapers.RowTemplate.Height = 33;
            this.dgvResearchPapers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvResearchPapers.Size = new System.Drawing.Size(959, 631);
            this.dgvResearchPapers.TabIndex = 0;
            // 
            // ManagePapersDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 809);
            this.Controls.Add(this.dataPanelPaper);
            this.Controls.Add(this.paperHeader);
            this.Name = "ManagePapersDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManagePapersDashboard";
            this.Load += new System.EventHandler(this.ManagePapersDashboard_Load);
            this.paperHeader.ResumeLayout(false);
            this.paperHeader.PerformLayout();
            this.dataPanelPaper.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResearchPapers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paperHeader;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearchPaper;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ComboBox cmbFilterPaper;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel dataPanelPaper;
        private System.Windows.Forms.DataGridView dgvResearchPapers;
    }
}