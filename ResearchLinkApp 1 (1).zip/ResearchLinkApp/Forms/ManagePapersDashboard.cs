﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using ResearchLinkApp.Utilities;

namespace ResearchLinkApp.Forms
{
    public partial class ManagePapersDashboard : Form
    {
        private DatabaseHelper dbHelper;
        

        public ManagePapersDashboard()
        {
            InitializeComponent();
            this.Load += ManagePapersDashboard_Load;
            dbHelper = new DatabaseHelper();

            // Event bindings
            cmbFilterPaper.SelectedIndexChanged += CmbFilterPaper_SelectedIndexChanged;
            txtSearchPaper.TextChanged += TxtSearchPaper_TextChanged;
            btnApprove.Click += BtnApprove_Click;
            btnReject.Click += BtnReject_Click;
            btnDelete.Click += BtnDelete_Click;
            
        }

        private void ManagePapersDashboard_Load(object sender, EventArgs e)
        {
            // Initialize the filter dropdown
            cmbFilterPaper.Items.Clear();
            cmbFilterPaper.Items.AddRange(new string[] { "Active", "Pending", "All" });
            cmbFilterPaper.SelectedIndex = 0;

            // Load all research papers
            LoadAllResearchPapers();

            // Adjust the DataGridView size and styling here
            dgvResearchPapers.Dock = DockStyle.Fill;
            dgvResearchPapers.BackgroundColor = Color.White;
            dgvResearchPapers.BorderStyle = BorderStyle.Fixed3D;
            dgvResearchPapers.RowHeadersVisible = false;
            dgvResearchPapers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void LoadAllResearchPapers()
        {
            try
            {
                DataTable papers = dbHelper.GetAllResearchPapers1();
                dgvResearchPapers.DataSource = papers;

                // Adjust DataGridView columns
                dgvResearchPapers.Columns["PaperID"].Visible = false; // Hide ID
                dgvResearchPapers.Columns["PaperTitle"].HeaderText = "Title";
                dgvResearchPapers.Columns["AuthorName"].HeaderText = "Author";
                dgvResearchPapers.Columns["Domain"].HeaderText = "Domain";
                dgvResearchPapers.Columns["Status"].HeaderText = "Status";
                dgvResearchPapers.Columns["ThumbnailLink"].Visible = false;
                dgvResearchPapers.Columns["CreatedDate"].Visible = false;
                dgvResearchPapers.Columns["UpdatedDate"].Visible = false;


                dgvResearchPapers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvResearchPapers.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading research papers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CmbFilterPaper_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedFilter = cmbFilterPaper.SelectedItem.ToString();
            try
            {
                DataTable filteredPapers;

                if (selectedFilter == "All")
                {
                    filteredPapers = dbHelper.GetAllResearchPapers();
                }
                else
                {
                    filteredPapers = dbHelper.FilterResearchPapersByStatus(selectedFilter);
                }

                dgvResearchPapers.DataSource = filteredPapers;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error filtering research papers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtSearchPaper_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearchPaper.Text.Trim();
            try
            {
                if (string.IsNullOrEmpty(searchText))
                {
                    LoadAllResearchPapers(); // Reload all papers if search is cleared
                }
                else
                {
                    DataTable searchResults = dbHelper.SearchResearchPapers(searchText);
                    dgvResearchPapers.DataSource = searchResults;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching research papers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnApprove_Click(object sender, EventArgs e)
        {
            if (dgvResearchPapers.SelectedRows.Count > 0)
            {
                int paperId = Convert.ToInt32(dgvResearchPapers.SelectedRows[0].Cells["PaperID"].Value);

                dbHelper.UpdateResearchPaperStatus(paperId, "Active");
                MessageBox.Show("Research paper approved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAllResearchPapers();
            }
            else
            {
                MessageBox.Show("Please select a research paper to approve.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnReject_Click(object sender, EventArgs e)
        {
            if (dgvResearchPapers.SelectedRows.Count > 0)
            {
                int paperId = Convert.ToInt32(dgvResearchPapers.SelectedRows[0].Cells["PaperID"].Value);

                // Update the status to "Rejected"
                dbHelper.UpdateResearchPaperStatus(paperId, "Rejected");

                MessageBox.Show("Research paper rejected successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Refresh the DataGridView
                LoadAllResearchPapers();
            }
            else
            {
                MessageBox.Show("Please select a research paper to reject.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvResearchPapers.SelectedRows.Count > 0)
            {
                int paperId = Convert.ToInt32(dgvResearchPapers.SelectedRows[0].Cells["PaperID"].Value);

                DialogResult confirm = MessageBox.Show(
                    "Are you sure you want to delete this research paper?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm == DialogResult.Yes)
                {
                    try
                    {
                        dbHelper.DeleteResearchPaper(paperId);
                        MessageBox.Show("Research paper deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadAllResearchPapers();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting research paper: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a research paper to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void btnAddPaper_Click(object sender, EventArgs e)
        {

        }
    }
}
