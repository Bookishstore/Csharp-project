﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class ManageUserDashboard : Form
    {
        private DatabaseHelper dbHelper;
        private int selectedUserId;
        public ManageUserDashboard()
        {
            InitializeComponent();
            this.Load += manageUserDashboard_Load;
            dbHelper = new DatabaseHelper();

            // Bind events
            txtSearch.TextChanged += TxtSearch_TextChanged;
            btnEditUser.Click += btnEditUser_Click_1;
            btnEditUser.Click -= btnEditUser_Click_1;

            // Adjust the DataGridView size and styling here
            dgvUsers.Dock = DockStyle.Fill;
            dgvUsers.BackgroundColor = Color.White;
            dgvUsers.BorderStyle = BorderStyle.Fixed3D;
            dgvUsers.RowHeadersVisible = false;
            dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void manageUserDashboard_Load(object sender, EventArgs e)
        {
            LoadAllUsers();


        }
        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchText))
            {
                SearchUsers(searchText);
            }
            else
            {
                LoadAllUsers();
            }
        }

        private void LoadAllUsers()
        {
            try
            {
                DataTable users = dbHelper.GetAllUsers();
                dgvUsers.DataSource = users;

                // Adjust columns
                dgvUsers.Columns["UserID"].HeaderText = "User ID";
                dgvUsers.Columns["Username"].HeaderText = "Username";
                dgvUsers.Columns["Email"].HeaderText = "Email";
                dgvUsers.Columns["Role"].HeaderText = "Role";
                dgvUsers.Columns["CreatedDate"].HeaderText = "Created Date";
                dgvUsers.Columns["UpdatedDate"].HeaderText = "Updated Date";

                dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvUsers.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading users: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SearchUsers(string searchText)
        {
            try
            {
                DataTable users = dbHelper.SearchUsers(searchText);
                dgvUsers.DataSource = users;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching users: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditUser_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (dgvUsers.SelectedRows.Count > 0)
                {
                    int userId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserID"].Value);

                    // Open the EditUserForm
                    EditUserForm editForm = new EditUserForm(userId);
                    editForm.Owner = this; // Set the parent form as the owner
                    editForm.ShowDialog();

                    // Refresh the data grid after editing
                    LoadAllUsers();
                }
                else
                {
                    MessageBox.Show("Please select a user to edit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error editing user: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void userHeader_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void ManageUserDashboard_Load_1(object sender, EventArgs e)
        {

        }

        private void dgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        
    }
}
