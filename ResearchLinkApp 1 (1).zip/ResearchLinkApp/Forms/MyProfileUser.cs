﻿using ResearchLinkApp.Models;
using ResearchLinkApp.Utilities;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class MyProfileUser : Form
    {
        private readonly int currentUserId;
        private readonly DatabaseHelper dbHelper;

        // You can still use an absolute path if you wish:
        // private readonly string profileImagePath = @"C:\C#\FirstProject\ResearchLinkApp\Resources\profile\";
        // But a relative path is often better for deployment:
        private readonly string profileImagePath = @"C:\C#\FirstProject\ResearchLinkApp\Resources\profile\";
        //private readonly string profileImagePath;

        public MyProfileUser(int currentUserId)
        {
            InitializeComponent();
            this.currentUserId = currentUserId;
            dbHelper = new DatabaseHelper();

            
            profileImagePath = Path.Combine(Application.StartupPath, "Resources", "profile");
            EnsureProfileDirectoryExists();

            pbProfilePicture.SizeMode = PictureBoxSizeMode.Zoom; 
        }

        private void MyProfileUser_Load(object sender, EventArgs e)
        {
            // Event bindings
            btnEditProfile.Click += BtnEditProfile_Click;
            btnSave.Click += BtnSave_Click;
            btnCancel.Click += btnCancel_Click;
            btnUpdatePicture.Click += BtnUpdatePicture_Click;

           
            LoadUserProfile();
        }

        /* private void EnsureProfileDirectoryExists()
         {
             try
             {
                 if (!Directory.Exists(profileImagePath))
                 {
                     Directory.CreateDirectory(profileImagePath);
                 }
             }
             catch (Exception ex)
             {
                 MessageBox.Show($"Error creating profile directory: {ex.Message}",
                     "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
         }*/

        private void EnsureProfileDirectoryExists()
        {
            try
            {
                if (!Directory.Exists(profileImagePath))
                {
                    Directory.CreateDirectory(profileImagePath);
                    // Optionally copy default.png here if needed
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating profile directory: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /* private void LoadUserProfile()
         {
             try
             {
                 DataRow userProfile = dbHelper.GetUserProfileById(currentUserId);
                 if (userProfile == null)
                 {
                     MessageBox.Show("User profile not found.", "Error",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                     this.Close();
                     return;
                 }

                 // Populate text fields
                 txtUsername.Text = userProfile["Username"]?.ToString() ?? string.Empty;
                 txtEmail.Text = userProfile["Email"]?.ToString() ?? string.Empty;
                 txtFullName.Text = userProfile["FullName"]?.ToString() ?? string.Empty;
                 txtNumber.Text = userProfile["ContactNumber"]?.ToString() ?? string.Empty;
                 rtxtBio.Text = userProfile["Bio"]?.ToString() ?? string.Empty;

                 // Handle profile picture
                 string profilePictureFile = userProfile["ProfilePicture"]?.ToString();
                 if (string.IsNullOrEmpty(profilePictureFile))
                 {
                     // If DB has no user-specific image, fallback to default
                     profilePictureFile = "default.png";
                 }

                 // Build the full path to the image file
                 string fullProfilePicturePath = Path.Combine(profileImagePath, profilePictureFile);



                 // If the file doesn't exist, fallback to default.png (if not already the default)
                 if (!File.Exists(fullProfilePicturePath) && profilePictureFile != "default.png")
                 {
                     fullProfilePicturePath = Path.Combine(profileImagePath, "default.png");
                 }

                 if (!File.Exists(fullProfilePicturePath))
                 {
                     pbProfilePicture.Image = null;
                     pbProfilePicture.ImageLocation = null;
                     Console.WriteLine("No default.png found. PictureBox set to null.");
                 }
                 else
                 {
                     // Load image
                     pbProfilePicture.Image = Image.FromFile(fullProfilePicturePath);

                     //Set ImageLocation so we can pick it up on Save
                     pbProfilePicture.ImageLocation = fullProfilePicturePath;
                 }


                 ToggleEditMode(false);
             }
             catch (Exception ex)
             {
                 MessageBox.Show($"Error loading user profile: {ex.Message}",
                     "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
         }*/

        private void LoadUserProfile()
        {
            try
            {
                DataRow userProfile = dbHelper.GetUserProfileById(currentUserId);
                if (userProfile == null)
                {
                    MessageBox.Show("User profile not found.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

                // Populate text fields
                txtUsername.Text = userProfile["Username"]?.ToString() ?? string.Empty;
                txtEmail.Text = userProfile["Email"]?.ToString() ?? string.Empty;
                txtFullName.Text = userProfile["FullName"]?.ToString() ?? string.Empty;
                txtNumber.Text = userProfile["ContactNumber"]?.ToString() ?? string.Empty;
                rtxtBio.Text = userProfile["Bio"]?.ToString() ?? string.Empty;

                // Handle profile picture
                string profilePictureFile = userProfile["ProfilePicture"]?.ToString();
                string fullProfilePicturePath;

                if (string.IsNullOrEmpty(profilePictureFile))
                {
                    // Use default image if no profile picture is set
                    fullProfilePicturePath = Path.Combine(profileImagePath, "default.png");
                }
                else
                {
                    fullProfilePicturePath = Path.Combine(profileImagePath, profilePictureFile);

                    // Fallback to default if the specified image doesn't exist
                    if (!File.Exists(fullProfilePicturePath))
                    {
                        fullProfilePicturePath = Path.Combine(profileImagePath, "default.png");
                    }
                }

                // Load the image
                if (File.Exists(fullProfilePicturePath))
                {
                    pbProfilePicture.Image = Image.FromFile(fullProfilePicturePath);
                    pbProfilePicture.ImageLocation = fullProfilePicturePath;
                }
                else
                {
                    // Handle missing default image
                    pbProfilePicture.Image = null;
                    pbProfilePicture.ImageLocation = null;
                    MessageBox.Show("Default profile image not found.", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                ToggleEditMode(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading user profile: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnEditProfile_Click(object sender, EventArgs e)
        {
            ToggleEditMode(true);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                string email = txtEmail.Text.Trim();
                string fullName = txtFullName.Text.Trim();
                string contactNumber = txtNumber.Text.Trim();
                string bio = rtxtBio.Text.Trim();

                if (string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Email is required.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrEmpty(fullName))
                {
                    MessageBox.Show("Full Name is required.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Determine what profile picture file to store in the DB.
                string profilePictureFileName = null;

                // If the PictureBox has an ImageLocation, we take the file name from it
                if (!string.IsNullOrEmpty(pbProfilePicture.ImageLocation))
                {
                    profilePictureFileName = Path.GetFileName(pbProfilePicture.ImageLocation);
                }

                // Debug: Log profile update details
                Console.WriteLine($"Updating Profile: Email={email}, FullName={fullName}, ContactNumber={contactNumber}, Bio={bio}, ProfilePicture={profilePictureFileName}");

                // Save to DB
                dbHelper.UpdateUserProfile(currentUserId, fullName, profilePictureFileName, contactNumber, bio, email);

                MessageBox.Show("Profile updated successfully.", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Reset form to view-only mode
                ToggleEditMode(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving profile: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /* private void BtnUpdatePicture_Click(object sender, EventArgs e)
         {
             using (OpenFileDialog fileDialog = new OpenFileDialog())
             {
                 fileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png";
                 fileDialog.Title = "Select a Profile Image";

                 if (fileDialog.ShowDialog() == DialogResult.OK)
                 {
                     try
                     {

                         string selectedFile = fileDialog.FileName;
                         string fileName = Path.GetFileName(selectedFile);
                         string destinationPath = Path.Combine(profileImagePath, fileName);

                         // Copy the file to the profile folder
                         File.Copy(selectedFile, destinationPath, true);

                         // Display in PictureBox
                         pbProfilePicture.Image = Image.FromFile(destinationPath);

                         // Set the ImageLocation so we know the filename on save
                         pbProfilePicture.ImageLocation = destinationPath;
                     }
                     catch (Exception ex)
                     {
                         MessageBox.Show($"Error updating profile picture: {ex.Message}",
                             "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     }
                 }
             }
         }*/

        private void BtnUpdatePicture_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog fileDialog = new OpenFileDialog())
            {
                fileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png";
                fileDialog.Title = "Select a Profile Image";

                if (fileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string selectedFile = fileDialog.FileName;
                        string fileName = Path.GetFileName(selectedFile);
                        string destinationPath = Path.Combine(profileImagePath, fileName);

                        File.Copy(selectedFile, destinationPath, true);
                        pbProfilePicture.Image = Image.FromFile(destinationPath);
                        pbProfilePicture.ImageLocation = destinationPath;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error updating profile picture: {ex.Message}",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ToggleEditMode(bool isEditable)
        {
            txtEmail.ReadOnly = !isEditable;
            txtFullName.ReadOnly = !isEditable;
            txtNumber.ReadOnly = !isEditable;
            rtxtBio.ReadOnly = !isEditable;
            btnCancel.Visible = isEditable;
            btnSave.Visible = isEditable;
            btnEditProfile.Visible = !isEditable;

            btnUpdatePicture.Visible = isEditable;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ToggleEditMode(false);
        }
    }
}
