﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using ResearchLinkApp.Models;
using ResearchLinkApp.Utilities;
using System.Data.SqlClient;


namespace ResearchLinkApp.Forms
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
            this.Load += RegistrationForm_Load;
        }
        private void RegistrationForm_Load(object sender, EventArgs e)
        {
            cmbRole.Items.Clear(); 
            cmbRole.Items.AddRange(new string[] { "Admin", "Author", "User" });
            cmbRole.SelectedIndex = -1; 
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        // Generates a cryptographic salt
        private byte[] GenerateSalt()
        {
            byte[] salt = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(salt);
            }
            return salt;
        }

        // Hashes the password with the provided salt
        private byte[] HashPassword(string password, byte[] salt)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] combined = Encoding.UTF8.GetBytes(password).Concat(salt).ToArray();
                return sha256.ComputeHash(combined);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = textPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;
            string email = txtEmail.Text.Trim();
            string degree = txtDegree.Text.Trim();
            string university = txtUniversity.Text.Trim();
            string role = cmbRole.SelectedItem?.ToString();

            // Input Validation
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword) ||
                string.IsNullOrEmpty(email) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Please fill in all required fields.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Generate Salt and Hash Password
                byte[] salt = GenerateSalt();
                byte[] hashedPassword = HashPassword(password, salt);
                byte[] storedPassword = salt.Concat(hashedPassword).ToArray();

                // Create User Object
                User newUser = new User
                {
                    Username = username,
                    Password = storedPassword,
                    Role = role,
                    Email = email
                };

                // Initialize Database Helper
                DatabaseHelper db = new DatabaseHelper();

                // Insert User and Get New UserID
                int newUserId = db.CreateUser(newUser);

                // Insert into tblUserProfile for the new user
                UserProfile newProfile = new UserProfile
                {
                    UserID = newUserId,
                    FullName = username, // Default to username or empty
                    ProfilePicture = null,
                    ContactNumber = string.Empty,
                    Bio = string.Empty
                };
                db.CreateUserProfile(newProfile);

                // If the role is "Author", insert into tblAuthor
                if (role.Equals("Author", StringComparison.OrdinalIgnoreCase))
                {
                    Author newAuthor = new Author
                    {
                        UserID = newUserId,
                        Degree = string.IsNullOrEmpty(degree) ? null : degree,
                        University = string.IsNullOrEmpty(university) ? null : university,
                        IsTopResearcher = false
                    };
                    db.CreateAuthor(newAuthor);
                }

                MessageBox.Show("Registration Successful! You can now log in.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Navigate back to Login Form
                this.Hide();
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 2627) // Unique constraint violation
                {
                    MessageBox.Show("Username or Email already exists. Please choose another.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("An error occurred during registration: " + sqlEx.Message, "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An unexpected error occurred: " + ex.Message, "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

        private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void RegistrationForm_Load_1(object sender, EventArgs e)
        {

        }
    }
}
