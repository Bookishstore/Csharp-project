﻿using ResearchLinkApp.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class ResearchPapersControl : Form
    {
        private int currentAuthorId;
        private DatabaseHelper dbHelper;

        public ResearchPapersControl(int authorId)
        {
            InitializeComponent();
            currentAuthorId = authorId;
            dbHelper = new DatabaseHelper();

            this.Load += ResearchPapersControl_Load;
            txtSearchPapers.TextChanged += txtSearchPapers_TextChanged;
            cmbFilter.SelectedIndexChanged += cmbFilter_SelectedIndexChanged;

            // Adjust the DataGridView size and styling here
            dvgResearchPapers.Dock = DockStyle.Fill;
            dvgResearchPapers.BackgroundColor = Color.White;
            dvgResearchPapers.BorderStyle = BorderStyle.Fixed3D;
            dvgResearchPapers.RowHeadersVisible = false;
            dvgResearchPapers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ResearchPapersControl_Load(object sender, EventArgs e)
        {
            // Initialize Filter Dropdown
            cmbFilter.Items.Clear();
            cmbFilter.Items.AddRange(new string[] { "Active", "Pending", "All" });
            cmbFilter.SelectedIndex = 2;

            // Load all research papers initially
            LoadAllResearchPapers();

            // Prevent multiple subscriptions to events
            btnAdd.Click -= btnAdd_Click;
            btnEdit.Click -= btnEdit_Click;
            btnRemove.Click -= btnRemove_Click;

            btnAdd.Click += btnAdd_Click;
            btnEdit.Click += btnEdit_Click;
            btnRemove.Click += btnRemove_Click;
        }

        public void LoadAllResearchPapers()
        {
            try
            {
                string query = @"SELECT DISTINCT rp.PaperID, rp.Title, rp.JournalLink, d.DomainName, rp.Status 
                                  FROM tblResearchPaper rp 
                                  JOIN tblDomain d ON rp.DomainID = d.DomainID
                                  WHERE rp.AuthorID = @AuthorID";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@AuthorID", currentAuthorId)
                };

                dvgResearchPapers.Columns["PaperID"].Visible = false;

                DataTable researchPapers = dbHelper.ExecuteReader(query, parameters);
                dvgResearchPapers.DataSource = researchPapers; // Bind the data to the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading research papers: " + ex.Message);
            }
        }

        public void ApplyFilter(string filter)
        {
            try
            {
                string query = @"SELECT DISTINCT rp.PaperID, rp.Title, rp.JournalLink, d.DomainName, rp.Status 
                                  FROM tblResearchPaper rp 
                                  JOIN tblDomain d ON rp.DomainID = d.DomainID
                                  WHERE rp.AuthorID = @AuthorID";

                // Add filter conditions
                if (filter == "Active")
                {
                    query += " AND rp.Status = 'Active'";
                }
                else if (filter == "Pending")
                {
                    query += " AND rp.Status = 'Pending'";
                }

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@AuthorID", currentAuthorId)
                };

                DataTable filteredData = dbHelper.ExecuteReader(query, parameters);
                dvgResearchPapers.DataSource = filteredData; // Bind filtered data to DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error applying filter: " + ex.Message);
            }
        }

        private void cmbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedFilter = cmbFilter.SelectedItem.ToString();
            ApplyFilter(selectedFilter);
        }

        private void txtSearchPapers_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearchPapers.Text.Trim();

            try
            {
                string query = @"SELECT DISTINCT rp.PaperID, rp.Title, rp.JournalLink, rp.ThumbnailLink, d.DomainName, rp.Status 
                                  FROM tblResearchPaper rp 
                                  JOIN tblDomain d ON rp.DomainID = d.DomainID
                                  WHERE rp.AuthorID = @AuthorID";

                if (!string.IsNullOrEmpty(searchText))
                {
                    query += " AND (rp.Title LIKE @SearchText OR d.DomainName LIKE @SearchText)";
                }

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@AuthorID", currentAuthorId),
                    new SqlParameter("@SearchText", "%" + searchText + "%")
                };

                DataTable searchData = dbHelper.ExecuteReader(query, parameters);
                dvgResearchPapers.DataSource = searchData; // Bind searched data to DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching research papers: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddResearchPaperForm addForm = new AddResearchPaperForm(currentAuthorId);
            addForm.Owner = this;
            addForm.ShowDialog();

            // Refresh the data after adding
            LoadAllResearchPapers();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dvgResearchPapers.SelectedRows.Count > 0)
            {
                int paperId = Convert.ToInt32(dvgResearchPapers.SelectedRows[0].Cells["PaperID"].Value);

                EditResearchPaperForm editForm = new EditResearchPaperForm(paperId);
                editForm.Owner = this;
                editForm.ShowDialog();

                // Refresh the data after editing
                LoadAllResearchPapers();
            }
            else
            {
                MessageBox.Show("Please select a research paper to edit.");
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dvgResearchPapers.SelectedRows.Count > 0)
            {
                int paperId = Convert.ToInt32(dvgResearchPapers.SelectedRows[0].Cells["PaperID"].Value);

                DialogResult confirm = MessageBox.Show(
                    "Are you sure you want to delete this research paper?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm == DialogResult.Yes)
                {
                    try
                    {
                        string query = "DELETE FROM tblResearchPaper WHERE PaperID = @PaperID";

                        SqlParameter[] parameters = new SqlParameter[]
                        {
                            new SqlParameter("@PaperID", paperId)
                        };

                        dbHelper.ExecuteNonQuery(query, parameters);
                        MessageBox.Show("Research paper deleted successfully.");

                        // Refresh the data after deletion
                        LoadAllResearchPapers();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting research paper: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a research paper to delete.");
            }
        }

        private void dvgResearchPapers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
