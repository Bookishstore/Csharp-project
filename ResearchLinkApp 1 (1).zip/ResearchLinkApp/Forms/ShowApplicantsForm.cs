﻿using ResearchLinkApp.Utilities;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class ShowApplicantsForm : Form
    {
        private int currentJobId;
        private int currentAuthorId;
        private DatabaseHelper dbHelper;
        private int selectedApplicationId;

        public ShowApplicantsForm(int jobId, int authorId)
        {
            InitializeComponent();

            currentJobId = jobId;
            currentAuthorId = authorId;
            dbHelper = new DatabaseHelper();

            // Events
            dgvApplications.SelectionChanged += dgvApplications_SelectionChanged;
            btnUpdate.Click += BtnUpdate_Click;

            // Row color-coding
            dgvApplications.RowPrePaint += DgvApplications_RowPrePaint;

            // Enable/disable RejectionReason
            cmbStatus.SelectedIndexChanged += CmbStatus_SelectedIndexChanged;

            dgvApplications.Dock = DockStyle.Fill;
            dgvApplications.BackgroundColor = Color.White;
            dgvApplications.BorderStyle = BorderStyle.Fixed3D;
            dgvApplications.RowHeadersVisible = false;
            dgvApplications.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        // FORM LOAD
        private void ShowApplicantsForm_Load(object sender, EventArgs e)
        {
            // 1) Populate combo box items
            cmbStatus.Items.Clear();
            cmbStatus.Items.Add("Pending");
            cmbStatus.Items.Add("Accepted");
            cmbStatus.Items.Add("Rejected");
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            // 2) Load the applicants
            LoadApplicants();
        }

        // =========== LOADING APPLICANTS ===========
        private void LoadApplicants()
        {
            // Just call the parameterized version with currentJobId
            LoadApplicantsByJob(currentJobId);
        }

        private void LoadApplicantsByJob(int jobId)
        {
            try
            {
                DataTable applicants = dbHelper.GetApplicationsByJob(jobId);
                dgvApplications.DataSource = applicants;

                // Set column headers
                dgvApplications.Columns["JobTitle"].HeaderText = "Job Title";
                dgvApplications.Columns["ApplicantName"].HeaderText = "Applicant";
                dgvApplications.Columns["ApplicationID"].HeaderText = "Application ID";
                dgvApplications.Columns["AppliedDate"].HeaderText = "Applied Date";
                dgvApplications.Columns["Status"].HeaderText = "Status";

                // Hide columns not displayed
                dgvApplications.Columns["ApplicationID"].Visible = false;
                dgvApplications.Columns["RejectionReason"].Visible = false;
                dgvApplications.Columns["ReviewedBy"].Visible = false;
                dgvApplications.Columns["DecisionDate"].Visible = false;

                dgvApplications.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading applicants: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // =========== ROW COLOR CODING ===========
        private void DgvApplications_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvApplications.Rows[e.RowIndex];
            var statusObj = row.Cells["Status"].Value;
            if (statusObj == null) return;

            string status = statusObj.ToString();

            if (status.Equals("Accepted", StringComparison.OrdinalIgnoreCase))
            {
                row.DefaultCellStyle.BackColor = Color.LightGreen;
            }
            else if (status.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
            {
                row.DefaultCellStyle.BackColor = Color.LightCoral;
            }
            else
            {
                // For Pending or anything else, default to white
                row.DefaultCellStyle.BackColor = Color.White;
            }
        }

        // =========== GRID SELECTION CHANGED ===========
        private void dgvApplications_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvApplications.SelectedRows.Count > 0)
                {
                    var selectedRow = dgvApplications.SelectedRows[0];

                    selectedApplicationId =
                        Convert.ToInt32(selectedRow.Cells["ApplicationID"].Value);

                    cmbStatus.Text =
                        selectedRow.Cells["Status"].Value?.ToString() ?? "";

                    rtxtRejectionReason.Text =
                        selectedRow.Cells["RejectionReason"].Value?.ToString() ?? "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error selecting application: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Enable/disable RejectionReason if status is "Rejected"
        private void CmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            rtxtRejectionReason.Enabled = (cmbStatus.Text == "Rejected");
        }

        // =========== UPDATE BUTTON CLICK ===========
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // 1) Ensure an application is selected
                if (selectedApplicationId <= 0)
                {
                    MessageBox.Show("Please select an application to update.",
                                    "Validation Error", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                // 2) Ensure a status is chosen
                if (string.IsNullOrEmpty(cmbStatus.Text))
                {
                    MessageBox.Show("Please select a status.",
                                    "Validation Error", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                string status = cmbStatus.Text;

                // 3) If "Rejected," ensure reason is provided
                if (status.Equals("Rejected", StringComparison.OrdinalIgnoreCase)
                    && string.IsNullOrWhiteSpace(rtxtRejectionReason.Text))
                {
                    MessageBox.Show("Please provide a rejection reason for rejected applications.",
                                    "Validation Error", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                // 4) Confirmation prompt
                DialogResult confirm = MessageBox.Show(
                    $"Are you sure you want to update the status to '{status}'?",
                    "Confirm Update",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirm == DialogResult.No) return;

                // 5) Do the update
               
                string rejectionReason = status.Equals("Rejected", StringComparison.OrdinalIgnoreCase)
                    ? rtxtRejectionReason.Text.Trim()
                    : null;

                // Here 'currentAuthorId' is the 'reviewedBy' param
                dbHelper.UpdateApplicationStatus(
                    selectedApplicationId,
                    status,
                    currentAuthorId,
                    rejectionReason
                );

                MessageBox.Show("Application status updated successfully.",
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 6) Refresh
                LoadApplicants();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating application status: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
