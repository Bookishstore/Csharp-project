﻿namespace ResearchLinkApp.Forms
{
    partial class UserControlAppliedJobs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.dgvAppliedJobs = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.contentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppliedJobs)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1276, 100);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(475, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(261, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Applied Jobs";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.contentPanel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1276, 709);
            this.panel2.TabIndex = 1;
            // 
            // contentPanel
            // 
            this.contentPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.contentPanel.Controls.Add(this.dgvAppliedJobs);
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentPanel.Location = new System.Drawing.Point(0, 0);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(1276, 709);
            this.contentPanel.TabIndex = 0;
            // 
            // dgvAppliedJobs
            // 
            this.dgvAppliedJobs.AllowUserToAddRows = false;
            this.dgvAppliedJobs.AllowUserToDeleteRows = false;
            this.dgvAppliedJobs.AllowUserToOrderColumns = true;
            this.dgvAppliedJobs.AllowUserToResizeColumns = false;
            this.dgvAppliedJobs.AllowUserToResizeRows = false;
            this.dgvAppliedJobs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAppliedJobs.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvAppliedJobs.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvAppliedJobs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvAppliedJobs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAppliedJobs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAppliedJobs.Location = new System.Drawing.Point(0, 0);
            this.dgvAppliedJobs.Name = "dgvAppliedJobs";
            this.dgvAppliedJobs.ReadOnly = true;
            this.dgvAppliedJobs.RowHeadersWidth = 82;
            this.dgvAppliedJobs.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvAppliedJobs.RowTemplate.Height = 33;
            this.dgvAppliedJobs.Size = new System.Drawing.Size(1276, 709);
            this.dgvAppliedJobs.TabIndex = 0;
            this.dgvAppliedJobs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAppliedJobs_CellContentClick);
            // 
            // UserControlAppliedJobs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1276, 809);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "UserControlAppliedJobs";
            this.Text = "UserControlAppliedJobs";
            this.Load += new System.EventHandler(this.UserControlAppliedJobs_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.contentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppliedJobs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.DataGridView dgvAppliedJobs;
    }
}