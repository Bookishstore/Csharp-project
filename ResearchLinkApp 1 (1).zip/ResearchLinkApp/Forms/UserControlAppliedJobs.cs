﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class UserControlAppliedJobs : Form
    {
        private int currentUserId;
        private DatabaseHelper dbHelper;
        public UserControlAppliedJobs(int currentUserId)
        {
            InitializeComponent();
            this.currentUserId = currentUserId;

            dbHelper = new DatabaseHelper();

            dgvAppliedJobs.Dock = DockStyle.Fill;
            dgvAppliedJobs.BackgroundColor = Color.White;
            dgvAppliedJobs.BorderStyle = BorderStyle.Fixed3D;
            dgvAppliedJobs.RowHeadersVisible = false;
            dgvAppliedJobs.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }



        private void UserControlAppliedJobs_Load(object sender, EventArgs e)
        {
            LoadAppliedJobs();

        }

        private void LoadAppliedJobs()
        {
            try
            {
                string query = @"
                SELECT
                jp.JobTitle AS [Job Title],
                ja.Status AS [Application Status],
                ja.AppliedDate AS [Applied Date],
                ja.DecisionDate AS [Decision Date],
                ja.RejectionReason AS [Rejection Reason]  -- <== add this
                FROM tblJobApplication ja
                JOIN tblJobPosting jp ON ja.JobID = jp.JobID
                WHERE ja.UserID = @UserID";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@UserID", currentUserId)
                };

                DataTable appliedJobs = dbHelper.ExecuteReader(query, parameters);
                dgvAppliedJobs.DataSource = appliedJobs;

                // Adjust column headers/sizing
                dgvAppliedJobs.Columns["Job Title"].Width = 200;
                dgvAppliedJobs.Columns["Application Status"].Width = 150;
                dgvAppliedJobs.Columns["Applied Date"].Width = 150;
                dgvAppliedJobs.Columns["Rejection Reason"].Width = 200; // new column
                dgvAppliedJobs.Columns["Decision Date"].Width = 150;

                // 3) Decide whether to show the "Rejection Reason" column
                bool anyRejected = false;
                foreach (DataGridViewRow row in dgvAppliedJobs.Rows)
                {
                    string status = row.Cells["Application Status"].Value?.ToString() ?? "";
                    if (status.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
                    {
                        anyRejected = true;
                        break;
                    }
                }

                // 4) Hide or show column
                dgvAppliedJobs.Columns["Rejection Reason"].Visible = anyRejected;


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading applied jobs: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void dgvAppliedJobs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
