﻿using ResearchLinkApp.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class UserControlJobs : Form
    {
        private int currentUserId;
        private DatabaseHelper dbHelper;
        public UserControlJobs(int currentUserId)
        {
            InitializeComponent();
            this.currentUserId = currentUserId;
            dbHelper = new DatabaseHelper();

            // Adjust the DataGridView size and styling here
            dgvJobs.Dock = DockStyle.Fill;
            dgvJobs.BackgroundColor = Color.White;
            dgvJobs.BorderStyle = BorderStyle.Fixed3D;
            dgvJobs.RowHeadersVisible = false;
            dgvJobs.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            btnApply.Click += btnApply_Click;
        }

        private void UserControlJobs_Load(object sender, EventArgs e)
        {
            LoadAvailableJobs();

        }

        private void LoadFormIntoPanel(Form form)
        {
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            contentPanel.Controls.Clear();
            contentPanel.Controls.Add(form);
            form.Show();
        }

        private void LoadAvailableJobs()
        {
            try
            {
                // Instantiate DatabaseHelper to fetch jobs
                DatabaseHelper dbHelper = new DatabaseHelper();

                // Fetch job postings
                DataTable jobs = dbHelper.GetAllJobPostings();

                // Bind jobs to DataGridView
                dgvJobs.DataSource = jobs;

                // Adjust column headers
                dgvJobs.Columns["JobTitle"].HeaderText = "Job Title";
                dgvJobs.Columns["Description"].HeaderText = "Description";
                dgvJobs.Columns["PostedBy"].HeaderText = "Posted By";
                dgvJobs.Columns["PostedDate"].HeaderText = "Posted Date";


                // Disable sorting and editing for a cleaner display
                foreach (DataGridViewColumn column in dgvJobs.Columns)
                {
                    column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    column.ReadOnly = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading jobs: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();

            if (!string.IsNullOrEmpty(searchText))
            {
                SearchJobs(searchText);
            }
            else
            {
                LoadAvailableJobs(); // Reload all jobs if the search box is cleared
            }
        }

        private void SearchJobs(string searchText)
        {
            try
            {
                // Prepare query to search for jobs
                string query = @"
                SELECT 
                jp.JobTitle AS JobTitle,
                jp.Description AS Description,
                u.Username AS PostedBy,
                jp.PostedDate AS PostedDate
                FROM tblJobPosting jp
                JOIN tblAuthor a ON jp.PostedByAuthorID = a.AuthorID
                JOIN tblUser u ON a.UserID = u.UserID
                WHERE jp.JobTitle LIKE @SearchText OR jp.Description LIKE @SearchText
                ORDER BY jp.PostedDate DESC";

                // Create parameters for the search query
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@SearchText", $"%{searchText}%")
                };

                // Execute the query and bind results to the DataGridView
                DatabaseHelper dbHelper = new DatabaseHelper();
                DataTable searchResults = dbHelper.ExecuteReader(query, parameters);

                dgvJobs.DataSource = searchResults;

                // Adjust column headers and formatting as needed
                dgvJobs.Columns["JobTitle"].HeaderText = "Job Title";
                dgvJobs.Columns["Description"].HeaderText = "Description";
                dgvJobs.Columns["PostedBy"].HeaderText = "Posted By";
                dgvJobs.Columns["PostedDate"].HeaderText = "Posted Date";

                // Hide the JobID column
                dgvJobs.Columns["JobID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching jobs: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            if (dgvJobs.SelectedRows.Count > 0)
            {
                // Ensure JobID column is present and fetch its value
                if (dgvJobs.Columns.Contains("JobID"))
                {
                    int selectedJobId = Convert.ToInt32(dgvJobs.SelectedRows[0].Cells["JobID"].Value);
                    string selectedJobTitle = dgvJobs.SelectedRows[0].Cells["JobTitle"].Value.ToString();

                    JobApplication applyJobForm = new JobApplication(currentUserId, selectedJobId, selectedJobTitle);
                    applyJobForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Job ID column is missing. Please check the job listing data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a job to apply for.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAppliedJobs_Click(object sender, EventArgs e)
        {
            UserControlAppliedJobs userControlAppliedJobs = new UserControlAppliedJobs(currentUserId);
            LoadFormIntoPanel(userControlAppliedJobs);

            //Hide apply button, txtSearch, label
            btnApply.Visible = false;
            btnAppliedJobs.Visible = false;
            txtSearch.Visible = false;
            lblSearch.Visible = false;
            lblTitle.Visible = false;
            headerPanel.Visible = false;

        }
    }
}
