﻿using ResearchLinkApp.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class UserControlResearch : Form
    {
        private int currentUserId;
        private DatabaseHelper dbHelper;

        public UserControlResearch(int currentUserId)
        {
            InitializeComponent();
            this.currentUserId = currentUserId;
            dbHelper = new DatabaseHelper();

            // Event subscriptions
            txtSearch.TextChanged += txtSearch_TextChanged;
            cmbDomain.SelectedIndexChanged += cmbDomain_SelectedIndexChanged;

            // Adjust the DataGridView size and styling here
            dgvResearchPapers.Dock = DockStyle.Fill;
            dgvResearchPapers.BackgroundColor = Color.White;
            dgvResearchPapers.BorderStyle = BorderStyle.Fixed3D;
            dgvResearchPapers.RowHeadersVisible = false;
            dgvResearchPapers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void UserControlResearch_Load(object sender, EventArgs e)
        {
            LoadDomains();
            LoadAllResearchPapers();
        }

        private void LoadDomains()
        {
            try
            {
                DataTable domains = dbHelper.GetAllDomains();

                // 1) Set the data source
                cmbDomain.DataSource = domains;

                // 2) Now set DisplayMember and ValueMember
                cmbDomain.DisplayMember = "DomainName";
                cmbDomain.ValueMember = "DomainID";

                // 3) (Optional) If you really want to force the default selection:
                if (domains.Rows.Count > 0)
                {
                    cmbDomain.SelectedIndex = 0;
                    // or cmbDomain.SelectedValue = domains.Rows[0]["DomainID"]
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading domains: {ex.Message}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void cmbDomain_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // Ensure the ComboBox is actually bound to an integer value
                if (cmbDomain.SelectedValue is int selectedDomainID)
                {
                    FilterResearchPapersByDomain(selectedDomainID);
                }
                // Otherwise, skip or handle gracefully, rather than showing an error
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error handling domain selection: {ex.Message}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }





        private void LoadAllResearchPapers()
        {
            try
            {
                DataTable researchPapers = dbHelper.GetAllResearchPapers();
                BindResearchPapersToGrid(researchPapers);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading research papers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void FilterResearchPapersByDomain(int domainID)
        {
            try
            {
                // Reuse your DatabaseHelper, which already has the active-only query
                DataTable dt = dbHelper.GetResearchPapersByDomain(domainID);

                // Now bind the results to the DataGridView
                BindResearchPapersToGrid(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error filtering papers: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();

            if (!string.IsNullOrEmpty(searchText))
            {
                SearchResearchPapersByTitle(searchText);
            }
            else
            {
                LoadAllResearchPapers(); // Reload all papers if the search box is empty
            }
        }

        private void SearchResearchPapersByTitle(string title)
        {
            try
            {
                DataTable searchResults = dbHelper.SearchResearchPapers(title);
                BindResearchPapersToGrid(searchResults);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching research papers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BindResearchPapersToGrid(DataTable researchPapers)
        {
            dgvResearchPapers.DataSource = researchPapers;

            // Adjust column headers for better readability
            if (researchPapers.Columns.Contains("Title"))
            {
                dgvResearchPapers.Columns["Title"].HeaderText = "Title";
                dgvResearchPapers.Columns["Title"].Width = 200;
            }

            if (researchPapers.Columns.Contains("Domain"))
            {
                dgvResearchPapers.Columns["Domain"].HeaderText = "Domain";
                dgvResearchPapers.Columns["Domain"].Width = 150;
            }

            if (researchPapers.Columns.Contains("JournalLink"))
            {
                dgvResearchPapers.Columns["JournalLink"].HeaderText = "Journal Link";
                dgvResearchPapers.Columns["JournalLink"].Width = 250;
                dgvResearchPapers.Columns["JournalLink"].DefaultCellStyle.Font = new System.Drawing.Font(dgvResearchPapers.Font, System.Drawing.FontStyle.Underline);
            }

            if (researchPapers.Columns.Contains("AuthorName"))
            {
                dgvResearchPapers.Columns["AuthorName"].HeaderText = "Author";
                dgvResearchPapers.Columns["AuthorName"].Width = 150;
            }
        }
    }
}
