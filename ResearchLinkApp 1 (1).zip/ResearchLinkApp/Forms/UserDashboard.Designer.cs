﻿namespace ResearchLinkApp.Forms
{
    partial class UserDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headerPanel = new System.Windows.Forms.Panel();
            this.lnkJobPostings = new System.Windows.Forms.LinkLabel();
            this.lnkResearchPapers = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.lnkMyProfile = new System.Windows.Forms.LinkLabel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.headerPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.headerPanel.Controls.Add(this.lnkMyProfile);
            this.headerPanel.Controls.Add(this.btnLogout);
            this.headerPanel.Controls.Add(this.lnkJobPostings);
            this.headerPanel.Controls.Add(this.lnkResearchPapers);
            this.headerPanel.Controls.Add(this.label1);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.headerPanel.Size = new System.Drawing.Size(1302, 100);
            this.headerPanel.TabIndex = 0;
            // 
            // lnkJobPostings
            // 
            this.lnkJobPostings.AutoSize = true;
            this.lnkJobPostings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkJobPostings.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkJobPostings.LinkColor = System.Drawing.Color.Black;
            this.lnkJobPostings.Location = new System.Drawing.Point(732, 44);
            this.lnkJobPostings.Name = "lnkJobPostings";
            this.lnkJobPostings.Size = new System.Drawing.Size(75, 29);
            this.lnkJobPostings.TabIndex = 5;
            this.lnkJobPostings.TabStop = true;
            this.lnkJobPostings.Text = " Jobs";
            this.lnkJobPostings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkJobPostings_LinkClicked);
            // 
            // lnkResearchPapers
            // 
            this.lnkResearchPapers.AutoSize = true;
            this.lnkResearchPapers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkResearchPapers.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkResearchPapers.LinkColor = System.Drawing.Color.Black;
            this.lnkResearchPapers.Location = new System.Drawing.Point(450, 44);
            this.lnkResearchPapers.Name = "lnkResearchPapers";
            this.lnkResearchPapers.Size = new System.Drawing.Size(208, 29);
            this.lnkResearchPapers.TabIndex = 4;
            this.lnkResearchPapers.TabStop = true;
            this.lnkResearchPapers.Text = "Research Papers";
            this.lnkResearchPapers.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkResearchPapers_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 16.125F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "ResearchLink";
            // 
            // contentPanel
            // 
            this.contentPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentPanel.Location = new System.Drawing.Point(0, 100);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(1302, 880);
            this.contentPanel.TabIndex = 1;
            // 
            // lnkMyProfile
            // 
            this.lnkMyProfile.AutoSize = true;
            this.lnkMyProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkMyProfile.Font = new System.Drawing.Font("Mongolian Baiti", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkMyProfile.LinkColor = System.Drawing.Color.Black;
            this.lnkMyProfile.Location = new System.Drawing.Point(906, 44);
            this.lnkMyProfile.Name = "lnkMyProfile";
            this.lnkMyProfile.Size = new System.Drawing.Size(143, 29);
            this.lnkMyProfile.TabIndex = 7;
            this.lnkMyProfile.TabStop = true;
            this.lnkMyProfile.Text = "My Profile";
            this.lnkMyProfile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkMyProfile_LinkClicked);
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = global::ResearchLinkApp.Properties.Resources.sign_out;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Location = new System.Drawing.Point(1201, 28);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(47, 45);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click_1);
            // 
            // UserDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 980);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.headerPanel);
            this.Name = "UserDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserDashboard";
            this.Load += new System.EventHandler(this.UserDashboard_Load);
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel lnkResearchPapers;
        private System.Windows.Forms.LinkLabel lnkJobPostings;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.LinkLabel lnkMyProfile;
    }
}