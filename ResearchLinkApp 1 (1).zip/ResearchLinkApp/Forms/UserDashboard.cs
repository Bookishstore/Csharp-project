﻿using ResearchLinkApp.Utilities;
using System;
using System.Windows.Forms;

namespace ResearchLinkApp.Forms
{
    public partial class UserDashboard : Form
    {
        private int userId;

        public UserDashboard(int userId)
        {
            InitializeComponent();
            this.userId = userId;

            // Subscribe to LinkLabel Click Events
            lnkResearchPapers.LinkClicked += lnkResearchPapers_LinkClicked;
            lnkJobPostings.LinkClicked += lnkJobPostings_LinkClicked;
            lnkMyProfile.LinkClicked += lnkMyProfile_LinkClicked;

            //Default open 
            UserControlResearch userControlResearch = new UserControlResearch(userId);
            LoadFormIntoPanel(userControlResearch);


        }

        private void UserDashboard_Load(object sender, EventArgs e)
        {

           
        }

        private void LoadFormIntoPanel(Form form)
        {
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            contentPanel.Controls.Clear();
            contentPanel.Controls.Add(form);
            form.Show();
        }




        private void lnkResearchPapers_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            UserControlResearch userControlResearch = new UserControlResearch(userId);
            LoadFormIntoPanel(userControlResearch);

        }

        

        private void lnkJobPostings_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            UserControlJobs UserJobPanel = new UserControlJobs(userId);
            LoadFormIntoPanel(UserJobPanel);
        }

        private void btnLogout_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Hide();
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }

        }

        private void lnkMyProfile_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MyProfileUser myProfileUser = new MyProfileUser(userId);
            LoadFormIntoPanel(myProfileUser);
        }
    }
}
