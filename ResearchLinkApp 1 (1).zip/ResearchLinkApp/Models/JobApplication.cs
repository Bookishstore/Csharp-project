﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchLinkApp.Models
{
    public class JobApplication
    {
        public int ApplicationID { get; set; }
        public int UserID { get; set; }
        public int JobID { get; set; }
        public DateTime AppliedDate { get; set; }
        public string AdditionalMessage { get; set; }
        public string Status { get; set; } // Pending, Accepted, Rejected
        public DateTime? DecisionDate { get; set; }
        public int? ReviewedBy { get; set; }
        public string RejectionReason { get; set; }
    }
}
