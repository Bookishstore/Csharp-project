﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchLinkApp.Models
{
    public class JobPosting
    {
        public int JobID { get; set; }
        public int PostedByAuthorID { get; set; }
        public string JobTitle { get; set; }
        public string Description { get; set; }
        public DateTime PostedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
