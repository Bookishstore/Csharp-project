﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchLinkApp.Models
{
    public class UserProfile
    {
        // User Information
        public int UserID { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }

        // Profile Information
        public string FullName { get; set; }
        public string ProfilePicture { get; set; } // File Path or URL
        public string ContactNumber { get; set; }
        public string Bio { get; set; }

        // Author Information
        public string Degree { get; set; }
        public string University { get; set; }


    }
}
