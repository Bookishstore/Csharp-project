﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ResearchLinkApp.Models;
using System.Text;
using System.Linq;

namespace ResearchLinkApp.Utilities
{
    public class DatabaseHelper
    {
        private string connectionString;

        public DatabaseHelper()
        {
            // Retrieve the connection string from App.config
            connectionString = ConfigurationManager.ConnectionStrings["ResearchLinkDB"].ConnectionString;
        }

        // Method to execute a non-query (INSERT, UPDATE, DELETE)


        public int ExecuteNonQuery(string query, SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    conn.Open();

                    // Debugging: Log the query and parameters
                    Console.WriteLine($"Executing Query: {query}");
                    foreach (var param in parameters)
                    {
                        Console.WriteLine($"{param.ParameterName}: {param.Value}");
                    }

                    int rowsAffected = cmd.ExecuteNonQuery();
                    Console.WriteLine($"Rows affected: {rowsAffected}");

                    return rowsAffected;
                }
            }
        }


        // Method to execute a scalar query (returns a single value)
        public object ExecuteScalar(string query, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }

        // Method to execute a reader (SELECT queries)
        public DataTable ExecuteReader(string query, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        return dt;
                    }
                }
            }
        }


        // Method to test the database connection
        public bool TestConnection()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return true;
                }
            }
            catch (Exception ex)
            {
                // Optionally, log the exception or display a message
                System.Windows.Forms.MessageBox.Show("Database Connection Failed: " + ex.Message);
                return false;
            }
        }

        // Create (Register a New User)
        public int CreateUser(User user)
        {
            string query = "INSERT INTO tblUser (Username, [Password], [Role], Email) VALUES (@Username, @Password, @Role, @Email); SELECT CAST(scope_identity() AS int);";

            SqlParameter[] parameters = new SqlParameter[]
            {
                 new SqlParameter("@Username", user.Username),
                 new SqlParameter("@Password", user.Password),
                 new SqlParameter("@Role", user.Role),
                 new SqlParameter("@Email", user.Email)
            };

            // Execute the query and return the new UserID
            return (int)ExecuteScalar(query, parameters);
        }

        public void CreateUserProfile(UserProfile profile)
        {
            string query = @"
            INSERT INTO tblUserProfile (UserID, FullName, ProfilePicture, ContactNumber, Bio)
            VALUES (@UserID, @FullName, @ProfilePicture, @ContactNumber, @Bio);";

            SqlParameter[] parameters = new SqlParameter[]
            {
            new SqlParameter("@UserID", profile.UserID),
            new SqlParameter("@FullName", string.IsNullOrEmpty(profile.FullName) ? string.Empty : profile.FullName),
            new SqlParameter("@ProfilePicture", profile.ProfilePicture ?? (object)DBNull.Value),
            new SqlParameter("@ContactNumber", string.IsNullOrEmpty(profile.ContactNumber) ? string.Empty : profile.ContactNumber),
            new SqlParameter("@Bio", string.IsNullOrEmpty(profile.Bio) ? string.Empty : profile.Bio)
            };

            ExecuteNonQuery(query, parameters);
        }


        // Read (Get User by Username)
        public User GetUserByUsername(string username)
        {
            string query = "SELECT * FROM tblUser WHERE Username = @Username";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Username", username)
            };

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                UserID = reader.GetInt32(reader.GetOrdinal("UserID")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                Password = (byte[])reader["Password"],
                                Role = reader.GetString(reader.GetOrdinal("Role")),
                                Email = reader.GetString(reader.GetOrdinal("Email"))
                                // Add other fields as necessary
                            };
                        }
                        else
                        {
                            return null; // User not found
                        }
                    }
                }
            }
        }

        // Read (Get User by ID)
        public User GetUserByID(int userId)
        {
            string query = "SELECT * FROM tblUser WHERE UserID = @UserID";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", userId)
            };

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters);
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                UserID = reader.GetInt32(reader.GetOrdinal("UserID")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                Password = (byte[])reader["Password"],
                                Role = reader.GetString(reader.GetOrdinal("Role")),
                                Email = reader.GetString(reader.GetOrdinal("Email"))
                                // Add other fields as necessary
                            };
                        }
                        else
                        {
                            return null; // User not found
                        }
                    }
                }
            }
        }

        public DataRow GetUserById(int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                SELECT UserID, Username, Email, Role, CreatedDate, UpdatedDate
                FROM tblUser
                WHERE UserID = @UserID";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", userId);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable userTable = new DataTable();
                    adapter.Fill(userTable);

                    // Return the first row if the user exists, otherwise return null
                    return userTable.Rows.Count > 0 ? userTable.Rows[0] : null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching user by ID: {ex.Message}");
            }
        }

        public bool ResetUserPassword(string email, byte[] hashedPassword, byte[] salt)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Combine the salt and hashed password
                    byte[] combinedPassword = salt.Concat(hashedPassword).ToArray();

                    string query = @"
                UPDATE tblUser
                SET Password = @Password
                WHERE Email = @Email";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Password", combinedPassword);
                    command.Parameters.AddWithValue("@Email", email);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error resetting password: {ex.Message}");
            }
        }



        public byte[] GenerateSalt(int size = 16)
        {
            using (var rng = new System.Security.Cryptography.RNGCryptoServiceProvider())
            {
                byte[] salt = new byte[size];
                rng.GetBytes(salt);
                return salt;
            }
        }

        public byte[] HashPassword(string password, byte[] salt)
        {
            using (var sha256 = new System.Security.Cryptography.SHA256CryptoServiceProvider())
            {
                // Combine the password and the salt
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] passwordWithSalt = new byte[passwordBytes.Length + salt.Length];
                Buffer.BlockCopy(passwordBytes, 0, passwordWithSalt, 0, passwordBytes.Length);
                Buffer.BlockCopy(salt, 0, passwordWithSalt, passwordBytes.Length, salt.Length);

                // Compute the hash
                return sha256.ComputeHash(passwordWithSalt);
            }
        }

        public DataRow GetUserProfileById(int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                SELECT 
                    up.ProfileID, 
                    up.UserID, 
                    u.Username, 
                    u.Email, 
                    up.FullName, 
                    up.ProfilePicture, 
                    up.ContactNumber, 
                    up.Bio
                FROM tblUserProfile up
                JOIN tblUser u ON up.UserID = u.UserID
                WHERE up.UserID = @UserID";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", userId);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();

                    adapter.Fill(resultTable);

                    if (resultTable.Rows.Count > 0)
                    {
                        return resultTable.Rows[0]; // Return the first row
                    }
                    else
                    {
                        return null; // No matching user profile found
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching user profile: {ex.Message}");
            }
        }

        public void UpdateUserProfile(int userId, string fullName, string profilePicture, string contactNumber, string bio, string email)
        {
            string query = @"
        BEGIN TRANSACTION;

        -- Update tblUserProfile
        IF EXISTS (SELECT 1 FROM tblUserProfile WHERE UserID = @UserID)
        BEGIN
            UPDATE tblUserProfile
            SET FullName = @FullName,
                ProfilePicture = @ProfilePicture,
                ContactNumber = @ContactNumber,
                Bio = @Bio
            WHERE UserID = @UserID;
        END
        ELSE
        BEGIN
            INSERT INTO tblUserProfile (UserID, FullName, ProfilePicture, ContactNumber, Bio)
            VALUES (@UserID, @FullName, @ProfilePicture, @ContactNumber, @Bio);
        END

        -- Update tblUser
        UPDATE tblUser
        SET Email = @Email, UpdatedDate = GETDATE()
        WHERE UserID = @UserID;

        COMMIT TRANSACTION;
    ";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", userId),
                new SqlParameter("@FullName", string.IsNullOrWhiteSpace(fullName) ? (object)DBNull.Value : fullName),
                new SqlParameter("@ProfilePicture", string.IsNullOrWhiteSpace(profilePicture) ? (object)DBNull.Value : profilePicture),
                new SqlParameter("@ContactNumber", string.IsNullOrWhiteSpace(contactNumber) ? (object)DBNull.Value : contactNumber),
                new SqlParameter("@Bio", string.IsNullOrWhiteSpace(bio) ? (object)DBNull.Value : bio),
                new SqlParameter("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email)
            };

            ExecuteNonQuery(query, parameters);
        }


        // Update (Update User Details)
        public void UpdateUser(User user)
        {
            string query = "UPDATE tblUser SET Username = @Username, [Password] = @Password, Role = @Role, Email = @Email, UpdatedDate = GETDATE() WHERE UserID = @UserID";

            SqlParameter[] parameters = new SqlParameter[]
            {
            new SqlParameter("@Username", user.Username),
            new SqlParameter("@Password", user.Password),
            new SqlParameter("@Role", user.Role),
            new SqlParameter("@Email", user.Email),
            new SqlParameter("@UserID", user.UserID)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Delete (Remove User)
        public void DeleteUser(int userId)
        {
            string query = "DELETE FROM tblUser WHERE UserID = @UserID";

            SqlParameter[] parameters = new SqlParameter[]
            {
        new SqlParameter("@UserID", userId)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Read (Get All Users)
        public DataTable GetAllUsers()
        {
            string query = "SELECT UserID, Username, Role, Email, CreatedDate, UpdatedDate FROM tblUser";
            return ExecuteReader(query);
        }

        // Create (Register a New Author)
        public int CreateAuthor(Author author)
        {
            string query = "INSERT INTO tblAuthor (UserID, Degree, University, IsTopResearcher) VALUES (@UserID, @Degree, @University, @IsTopResearcher); SELECT CAST(scope_identity() AS int);";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", author.UserID),
                new SqlParameter("@Degree", string.IsNullOrEmpty(author.Degree) ? (object)DBNull.Value : author.Degree),
                new SqlParameter("@University", string.IsNullOrEmpty(author.University) ? (object)DBNull.Value : author.University),
                new SqlParameter("@IsTopResearcher", author.IsTopResearcher)
            };

            // Execute the query and return the new AuthorID
            return (int)ExecuteScalar(query, parameters);
        }

        // Read (Get Author by UserID)
        public Author GetAuthorByUserId(int userId)
        {
            string query = "SELECT AuthorID, UserID, Degree, University, IsTopResearcher FROM tblAuthor WHERE UserID = @UserID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", userId)
            };

            DataTable dt = ExecuteReader(query, parameters);

            if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];
                return new Author
                {
                    AuthorID = Convert.ToInt32(row["AuthorID"]),
                    UserID = Convert.ToInt32(row["UserID"]),
                    Degree = row["Degree"] != DBNull.Value ? row["Degree"].ToString() : null,
                    University = row["University"] != DBNull.Value ? row["University"].ToString() : null,
                    IsTopResearcher = Convert.ToBoolean(row["IsTopResearcher"])
                };
            }
            else
            {
                return null; // Author not found
            }
        }

        // Update (Update Author Details)
        public void UpdateAuthor(Author author)
        {
            string query = "UPDATE tblAuthor SET Degree = @Degree, University = @University, IsTopResearcher = @IsTopResearcher WHERE AuthorID = @AuthorID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Degree", string.IsNullOrEmpty(author.Degree) ? (object)DBNull.Value : author.Degree),
                new SqlParameter("@University", string.IsNullOrEmpty(author.University) ? (object)DBNull.Value : author.University),
                new SqlParameter("@IsTopResearcher", author.IsTopResearcher),
                new SqlParameter("@AuthorID", author.AuthorID)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Delete (Remove Author)
        public void DeleteAuthor(int authorId)
        {
            string query = "DELETE FROM tblAuthor WHERE AuthorID = @AuthorID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@AuthorID", authorId)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Read (Get All Authors)
        public DataTable GetAllAuthors()
        {
            string query = "SELECT a.AuthorID, u.Username, a.Degree, a.University, a.IsTopResearcher FROM tblAuthor a JOIN tblUser u ON a.UserID = u.UserID";
            return ExecuteReader(query);
        }

        /*Implement CRUD Methods for the ResearchPaper Model*/
        // Create (Add a New Research Paper)
        public int CreateResearchPaper(ResearchPaper paper)
        {
            string query = @"
                INSERT INTO tblResearchPaper 
                (Title, JournalLink, ThumbnailLink, DomainID, AuthorID, Status, CreatedDate)
                VALUES (@Title, @JournalLink, @ThumbnailLink, @DomainID, @AuthorID, @Status, @CreatedDate); 
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Title", paper.Title),
                new SqlParameter("@JournalLink", string.IsNullOrEmpty(paper.JournalLink) ? (object)DBNull.Value : paper.JournalLink),
                new SqlParameter("@ThumbnailLink", string.IsNullOrEmpty(paper.ThumbnailLink) ? (object)DBNull.Value : paper.ThumbnailLink),
                new SqlParameter("@DomainID", paper.DomainID),
                new SqlParameter("@AuthorID", paper.AuthorID),
                new SqlParameter("@Status", paper.Status),
                new SqlParameter("@CreatedDate", paper.CreatedDate)
            };

            return (int)ExecuteScalar(query, parameters);
        }


        // Read (Get Research Paper by PaperID)
        // In DatabaseHelper.cs
        public ResearchPaper GetResearchPaperById(int paperId)
        {
            string query = @"SELECT 
                rp.PaperID,
                rp.Title AS Title,   
                 rp.JournalLink,
                rp.ThumbnailLink,
                rp.DomainID,
                rp.CreatedDate,
                rp.UpdatedDate
                FROM tblResearchPaper rp
                WHERE rp.PaperID = @PaperID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@PaperID", paperId)
            };

            DataTable dt = ExecuteReader(query, parameters);

            if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];
                return new ResearchPaper
                {
                    PaperID = Convert.ToInt32(row["PaperID"]),
                    Title = row["Title"].ToString(),
                    JournalLink = row["JournalLink"] != DBNull.Value ? row["JournalLink"].ToString() : null,
                    ThumbnailLink = row["ThumbnailLink"] != DBNull.Value ? row["ThumbnailLink"].ToString() : null,
                    DomainID = Convert.ToInt32(row["DomainID"]),
                    CreatedDate = Convert.ToDateTime(row["CreatedDate"]),
                    UpdatedDate = row["UpdatedDate"] != DBNull.Value ? (DateTime?)Convert.ToDateTime(row["UpdatedDate"]) : null
                };
            }
            else
            {
                return null; // Research Paper not found
            }
        }
        // Read (Get All Active Research papers)
        public DataTable GetAllResearchPapers()
        {
            string query = @"
             SELECT 
            
            rp.Title, 
            rp.JournalLink, 
            
            d.DomainName, 
            rp.CreatedDate
            
            FROM tblResearchPaper rp 
            JOIN tblDomain d ON rp.DomainID = d.DomainID
            WHERE rp.Status = 'Active'
            ORDER BY rp.CreatedDate DESC";

            return ExecuteReader(query, null);
        }

        public DataTable GetAllResearchPapers1()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @" SELECT 
                                        rp.PaperID, 
                                        rp.Title AS PaperTitle, 
                                        rp.JournalLink, 
                                        rp.ThumbnailLink, 
                                        d.DomainName AS Domain, 
                                        u.Username AS AuthorName, 
                                        rp.Status, 
                                         rp.CreatedDate, 
                                         rp.UpdatedDate
                                        FROM tblResearchPaper rp
                                        JOIN tblDomain d ON rp.DomainID = d.DomainID
                                        JOIN tblAuthor a ON rp.AuthorID = a.AuthorID
                                        JOIN tblUser u ON a.UserID = u.UserID
                                        ORDER BY rp.CreatedDate DESC;
                                       ";

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    DataTable papers = new DataTable();
                    adapter.Fill(papers);

                    return papers;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching research papers: {ex.Message}");
            }
        }




        // Update (Update Research Paper Details)
        public void UpdateResearchPaper(ResearchPaper paper)
        {
            string query = @"UPDATE tblResearchPaper
                            SET 
                            Title = @Title,
                             JournalLink = @JournalLink,
                            ThumbnailLink = @ThumbnailLink,
                            DomainID = @DomainID
                            WHERE PaperID = @PaperID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Title", paper.Title),
                new SqlParameter("@JournalLink", (object)paper.JournalLink ?? DBNull.Value),
                new SqlParameter("@ThumbnailLink", (object)paper.ThumbnailLink ?? DBNull.Value),
                new SqlParameter("@DomainID", paper.DomainID),
                new SqlParameter("@PaperID", paper.PaperID)
            };

            ExecuteNonQuery(query, parameters);
        }


        // Delete (Remove Research Paper)
        public void DeleteResearchPaper(int paperId)
        {
            string query = "DELETE FROM tblResearchPaper WHERE PaperID = @PaperID";

            SqlParameter[] parameters = new SqlParameter[]
            {
        new SqlParameter("@PaperID", paperId)
            };

            ExecuteNonQuery(query, parameters);
        }

        /* Implement CRUD Methods for the JobPosting Model*/
        // Create (Add a New Job Posting)
        public void CreateJobPosting(JobPosting jobPosting)
        {
            string query = @"INSERT INTO tblJobPosting (PostedByAuthorID, JobTitle, Description, PostedDate)
                         VALUES (@PostedByAuthorID, @JobTitle, @Description, @PostedDate)";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@PostedByAuthorID", jobPosting.PostedByAuthorID),
                new SqlParameter("@JobTitle", jobPosting.JobTitle),
                new SqlParameter("@Description", string.IsNullOrEmpty(jobPosting.Description) ? (object)DBNull.Value : jobPosting.Description),
                new SqlParameter("@PostedDate", jobPosting.PostedDate)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Read (Get Job Posting by JobID)
        public DataTable GetJobPostingsByAuthor(int authorId)
        {
            string query = @"SELECT JobID, JobTitle, Description, PostedDate
                         FROM tblJobPosting
                         WHERE PostedByAuthorID = @AuthorID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@AuthorID", authorId)
            };

            return ExecuteReader(query, parameters);
        }

        // Read (Get All Job Postings)
        public DataTable GetAllJobPostings()
        {
            string query = "SELECT jp.JobID, a.Username AS PostedBy, jp.JobTitle, jp.Description, jp.PostedDate FROM tblJobPosting jp JOIN tblAuthor au ON jp.PostedByAuthorID = au.AuthorID JOIN tblUser a ON au.UserID = a.UserID";
            return ExecuteReader(query);
        }

        // Update (Update Job Posting Details)
        public void UpdateJobPosting(JobPosting jobPosting)
        {
            string query = @"UPDATE tblJobPosting
                         SET JobTitle = @JobTitle, 
                             Description = @Description, 
                             UpdatedDate = @UpdatedDate
                         WHERE JobID = @JobID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@JobID", jobPosting.JobID),
                new SqlParameter("@JobTitle", jobPosting.JobTitle),
                new SqlParameter("@Description", string.IsNullOrEmpty(jobPosting.Description) ? (object)DBNull.Value : jobPosting.Description),
                new SqlParameter("@UpdatedDate", DateTime.Now)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Delete (Remove Job Posting)
        public void DeleteJobPosting(int jobId)
        {
            string query = @"DELETE FROM tblJobPosting WHERE JobID = @JobID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@JobID", jobId)
            };

            ExecuteNonQuery(query, parameters);
        }

        /* Implement CRUD Methods for the JobApplication Model*/
        // Create (Add a New Job Application)
        public int CreateJobApplication(JobApplication application)
        {
            string query = "INSERT INTO tblJobApplication (UserID, JobID, AdditionalMessage) VALUES (@UserID, @JobID, @AdditionalMessage); SELECT CAST(scope_identity() AS int);";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", application.UserID),
                new SqlParameter("@JobID", application.JobID),
                new SqlParameter("@AdditionalMessage", string.IsNullOrEmpty(application.AdditionalMessage) ? (object)DBNull.Value : application.AdditionalMessage)
            };

            // Execute the query and return the new ApplicationID
            return (int)ExecuteScalar(query, parameters);
        }

        // Read (Get Job Application by ApplicationID)
        public JobApplication GetJobApplicationById(int applicationId)
        {
            string query = "SELECT ApplicationID, UserID, JobID, AppliedDate, AdditionalMessage, Status, DecisionDate, ReviewedBy, RejectionReason FROM tblJobApplication WHERE ApplicationID = @ApplicationID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ApplicationID", applicationId)
            };

            DataTable dt = ExecuteReader(query, parameters);

            if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];
                return new JobApplication
                {
                    ApplicationID = Convert.ToInt32(row["ApplicationID"]),
                    UserID = Convert.ToInt32(row["UserID"]),
                    JobID = Convert.ToInt32(row["JobID"]),
                    AppliedDate = Convert.ToDateTime(row["AppliedDate"]),
                    AdditionalMessage = row["AdditionalMessage"] != DBNull.Value ? row["AdditionalMessage"].ToString() : null,
                    Status = row["Status"].ToString(),
                    DecisionDate = row["DecisionDate"] != DBNull.Value ? (DateTime?)Convert.ToDateTime(row["DecisionDate"]) : null,
                    ReviewedBy = row["ReviewedBy"] != DBNull.Value ? (int?)Convert.ToInt32(row["ReviewedBy"]) : null,
                    RejectionReason = row["RejectionReason"] != DBNull.Value ? row["RejectionReason"].ToString() : null
                };
            }
            else
            {
                return null; // Job Application not found
            }
        }

        // Read (Get All Job Applications)
        public DataTable GetApplicationsByJob(int jobId)
        {
            string query = @"
                SELECT ja.ApplicationID,
               jp.JobTitle,
               u.Username AS ApplicantName,
               ja.AppliedDate,
               ja.Status,
               ja.AdditionalMessage,
               ja.RejectionReason,
               ja.ReviewedBy,
               ja.DecisionDate
                FROM tblJobApplication ja
                JOIN tblJobPosting jp ON ja.JobID = jp.JobID
                JOIN tblUser u ON ja.UserID = u.UserID
                WHERE ja.JobID = @JobID
                ORDER BY ja.AppliedDate DESC
            ";

            SqlParameter[] parameters =
            {
                new SqlParameter("@JobID", jobId)
            };

            return ExecuteReader(query, parameters);
        }

        // Update (Update Job Application Status)
        public void UpdateApplicationStatus(int applicationId, string status, int reviewedBy, string rejectionReason = null)
        {
            string query = @"UPDATE tblJobApplication
                         SET Status = @Status, 
                             ReviewedBy = @ReviewedBy, 
                             DecisionDate = @DecisionDate, 
                             RejectionReason = @RejectionReason
                         WHERE ApplicationID = @ApplicationID";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Status", status),
                new SqlParameter("@ReviewedBy", reviewedBy),
                new SqlParameter("@DecisionDate", DateTime.Now),
                new SqlParameter("@RejectionReason", string.IsNullOrEmpty(rejectionReason) ? (object)DBNull.Value : rejectionReason),
                new SqlParameter("@ApplicationID", applicationId)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Delete (Remove Job Application)
        public void DeleteJobApplication(int applicationId)
        {
            string query = "DELETE FROM tblJobApplication WHERE ApplicationID = @ApplicationID";

            SqlParameter[] parameters = new SqlParameter[]
            {
            new SqlParameter("@ApplicationID", applicationId)
            };

            ExecuteNonQuery(query, parameters);
        }

        //Add Domain
        public int AddDomain(string domainName)
        {
            // Check if the domain already exists
            string checkQuery = "SELECT COUNT(*) FROM tblDomain WHERE DomainName = @DomainName";
            SqlParameter[] checkParams = new SqlParameter[]
            {
                new SqlParameter("@DomainName", domainName)
            };
            int count = Convert.ToInt32(ExecuteScalar(checkQuery, checkParams));

            if (count > 0)
            {
                // Domain already exists
                throw new Exception("This domain already exists.");
            }

            // Insert the new domain
            string insertQuery = "INSERT INTO tblDomain (DomainName) VALUES (@DomainName); SELECT CAST(scope_identity() AS int);";
            SqlParameter[] insertParams = new SqlParameter[]
            {
                new SqlParameter("@DomainName", domainName)
            };

            return (int)ExecuteScalar(insertQuery, insertParams);
        }

        //Get All Domains
        public DataTable GetAllDomains()
        {
            string query = "SELECT DomainID, DomainName FROM tblDomain ORDER BY DomainName";

            return ExecuteReader(query);
        }




        //GetUser Profile
        public DataTable GetUserProfile(int userId)
        {
            string query = @"SELECT 
                        u.Email,
                        up.FullName, 
                        up.ProfilePicture, 
                        up.ContactNumber, 
                        up.Bio,
                        a.Degree, 
                        a.University
                     FROM tblUser u
                     LEFT JOIN tblUserProfile up ON u.UserID = up.UserID
                     LEFT JOIN tblAuthor a ON u.UserID = a.UserID
                     WHERE u.UserID = @UserID";

            SqlParameter[] parameters = new SqlParameter[]
            {
        new SqlParameter("@UserID", userId)
            };

            return ExecuteReader(query, parameters);
        }


        //Update User Profile
        public int UpdateUserProfile(UserProfile profile)
        {
            try
            {
                string query = @"
        UPDATE tblUser
        SET Email = @Email
        WHERE UserID = @UserID;

        UPDATE tblUserProfile
        SET FullName = @FullName,
            ContactNumber = @ContactNumber,
            Bio = @Bio,
            ProfilePicture = @ProfilePicture
        WHERE UserID = @UserID;

        UPDATE tblAuthor
        SET Degree = @Degree,
            University = @University
        WHERE UserID = @UserID;
        ";

                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@UserID", profile.UserID),
            new SqlParameter("@Email", profile.Email),
            new SqlParameter("@FullName", profile.FullName),
            new SqlParameter("@ContactNumber", profile.ContactNumber),
            new SqlParameter("@Bio", profile.Bio),
            new SqlParameter("@ProfilePicture", profile.ProfilePicture ?? (object)DBNull.Value),
            new SqlParameter("@Degree", profile.Degree ?? (object)DBNull.Value),
            new SqlParameter("@University", profile.University ?? (object)DBNull.Value)
                };

                int rowsAffected = ExecuteNonQuery(query, parameters);
                Console.WriteLine($"Rows affected in UpdateUserProfile: {rowsAffected}");
                return rowsAffected;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in UpdateUserProfile: {ex.Message}");
                throw;
            }
        }

        public void UpdateUserProfilePicture(int userId, string profilePicturePath)
        {
            string query = @"UPDATE tblUserProfile
                     SET ProfilePicture = @ProfilePicture
                     WHERE UserID = @UserID";

            SqlParameter[] parameters = new SqlParameter[]
            {
               new SqlParameter("@UserID", userId),
                new SqlParameter("@ProfilePicture", profilePicturePath ?? (object)DBNull.Value)
            };

            ExecuteNonQuery(query, parameters);
        }

        //Fetch Latest Research Papers
        public DataTable GetLatestResearchPapers(int limit)
        {
            string query = @"
            SELECT TOP (@Limit) 
            rp.Title, 
            d.DomainName AS Domain, 
            rp.JournalLink, 
            u.Username AS AuthorName
            FROM tblResearchPaper rp
            JOIN tblDomain d ON rp.DomainID = d.DomainID
            JOIN tblAuthor a ON rp.AuthorID = a.AuthorID
            JOIN tblUser u ON a.UserID = u.UserID
            WHERE rp.Status = 'Active'
            ORDER BY rp.CreatedDate DESC";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Limit", limit)
            };

            return ExecuteReader(query, parameters);
        }


        //Fetch Latest Jobs
        public DataTable GetLatestJobs(int limit)
        {
            string query = @"SELECT TOP (@Limit) 
                        jp.JobTitle AS Title, 
                        jp.Description, 
                        u.Username AS AuthorName
                     FROM tblJobPosting jp
                     JOIN tblAuthor a ON jp.PostedByAuthorID = a.AuthorID
                     JOIN tblUser u ON a.UserID = u.UserID
                     ORDER BY jp.PostedDate DESC";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Limit", limit)
            };

            return ExecuteReader(query, parameters);
        }

        // For filtering by domain
        public DataTable GetResearchPapersByDomain(int domainId)
        {
            string query = @"
            SELECT  
            rp.Title, 
            rp.JournalLink,  
            d.DomainName, 
            rp.CreatedDate
            FROM tblResearchPaper rp 
            JOIN tblDomain d ON rp.DomainID = d.DomainID
            WHERE rp.DomainID = @DomainID 
            AND rp.Status = 'Active'
            ORDER BY rp.CreatedDate DESC";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@DomainID", domainId)
            };

            return ExecuteReader(query, parameters);
        }

        // For searching by title
        public DataTable SearchResearchPapers(string searchTerm)
        {
            string query = @"
            SELECT 
            rp.PaperID, 
            rp.Title, 
            rp.JournalLink, 
            rp.ThumbnailLink, 
            d.DomainName, 
            rp.CreatedDate, 
            rp.UpdatedDate 
            FROM tblResearchPaper rp 
            JOIN tblDomain d ON rp.DomainID = d.DomainID
            WHERE rp.Title LIKE @SearchTerm 
            AND rp.Status = 'Active'
            ORDER BY rp.CreatedDate DESC";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@SearchTerm", $"%{searchTerm}%")
            };

            return ExecuteReader(query, parameters);
        }

        public DataTable SearchUsers(string searchText)
        {
            string query = "SELECT UserID, Username, Email, Role, CreatedDate, UpdatedDate FROM tblUser WHERE Username LIKE @Search OR Email LIKE @Search";
            SqlParameter[] parameters = { new SqlParameter("@Search", $"%{searchText}%") };
            return ExecuteReader(query, parameters);
        }

        public void UpdateUserEmail(int userId, string email)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"UPDATE tblUser SET Email = @Email, UpdatedDate = GETDATE() WHERE UserID = @UserID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", userId);
                    command.Parameters.AddWithValue("@Email", email);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating user email: {ex.Message}");
            }
        }
        public DataTable FilterResearchPapersByStatus(string status)
        {
            string query = @"SELECT * FROM tblResearchPaper WHERE Status = @Status";
            SqlParameter[] parameters = { new SqlParameter("@Status", status) };
            return ExecuteReader(query, parameters);
        }

        public void UpdateResearchPaperStatus(int paperId, string status)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                UPDATE tblResearchPaper
                SET Status = @Status
                WHERE PaperID = @PaperID";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Status", status);
                    command.Parameters.AddWithValue("@PaperID", paperId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating research paper status: {ex.Message}");
            }
        }

        public void DeleteResearchPaper1(int paperId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM tblResearchPaper WHERE PaperID = @PaperID";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@PaperID", paperId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deleting research paper: {ex.Message}");
            }
        }

        public DataTable SearchJobPostings(string searchText)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                SELECT 
                    jp.JobID,
                    jp.JobTitle,
                    u.Username AS PostedBy,
                    jp.Description,
                    jp.PostedDate
                FROM tblJobPosting jp
                JOIN tblAuthor a ON jp.PostedByAuthorID = a.AuthorID
                JOIN tblUser u ON a.UserID = u.UserID
                WHERE jp.JobTitle LIKE @SearchText OR jp.Description LIKE @SearchText
                ORDER BY jp.PostedDate DESC";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SearchText", $"%{searchText}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable searchResults = new DataTable();
                    adapter.Fill(searchResults);

                    return searchResults;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error searching job postings: {ex.Message}");
            }
        }

        public int GetTotalUsers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT COUNT(*) FROM tblUser";
                    SqlCommand command = new SqlCommand(query, connection);

                    connection.Open();
                    int totalUsers = Convert.ToInt32(command.ExecuteScalar());
                    return totalUsers;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching total users: {ex.Message}");
            }
        }

        public int GetTotalAuthors()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT COUNT(*) FROM tblAuthor";
                    SqlCommand command = new SqlCommand(query, connection);

                    connection.Open();
                    int totalAuthors = Convert.ToInt32(command.ExecuteScalar());
                    return totalAuthors;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching total authors: {ex.Message}");
            }
        }

        public int GetTotalResearchPapers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT COUNT(*) FROM tblResearchPaper";
                    SqlCommand command = new SqlCommand(query, connection);

                    connection.Open();
                    int totalResearchPapers = Convert.ToInt32(command.ExecuteScalar());
                    return totalResearchPapers;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching total research papers: {ex.Message}");
            }
        }

        public int GetTotalJobs()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT COUNT(*) FROM tblJobPosting";
                    SqlCommand command = new SqlCommand(query, connection);

                    connection.Open();
                    int totalJobs = Convert.ToInt32(command.ExecuteScalar());
                    return totalJobs;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching total jobs: {ex.Message}");
            }
        }
























    }
}
